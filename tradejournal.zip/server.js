const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const optionalTradeColumns = [
  ['position_size', 'DECIMAL(20,8) NULL'],
  ['pnl', 'DECIMAL(20,8) NULL'],
  ['strategy', 'VARCHAR(160) NULL'],
  ['emotion', 'VARCHAR(40) NULL'],
  ['discipline', 'VARCHAR(60) NULL'],
  ['trade_time', 'TIME NULL'],
  ['price_mode', "ENUM('price','pips') NULL"],
  ['stop_loss_pips', 'DECIMAL(20,8) NULL'],
  ['take_profit_pips', 'DECIMAL(20,8) NULL'],
];
const mysql = require('mysql2/promise');

const root = path.join(__dirname, 'public');
const port = Number(process.env.PORT || 3000);
const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
};

let db;

function publicOrigin(req) {
  const forwardedProto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  const forwardedHost = String(req.headers['x-forwarded-host'] || '').split(',')[0].trim();
  const host = forwardedHost || req.headers.host;
  const proto = forwardedProto || (/^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host || '') ? 'http' : 'https');
  return `${proto}://${host}`;
}

function isPublicHttps(req) {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  const host = String(req.headers.host || '');
  return proto === 'https' || !/^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host);
}

function cookieAttributes(req, maxAge) {
  const attributes = [`Path=/`, `Max-Age=${maxAge}`, 'HttpOnly', 'SameSite=None'];
  if (isPublicHttps(req)) attributes.push('Secure');
  return attributes.join('; ');
}

function setCookie(res, req, name, value, maxAge) {
  res.setHeader('Set-Cookie', `${name}=${encodeURIComponent(value)}; ${cookieAttributes(req, maxAge)}`);
}

function isSameOrigin(req) {
  const origin = String(req.headers.origin || '').trim();
  return !origin || origin === publicOrigin(req);
}

function allowCrossOrigin(req, res, methods = 'GET, POST, OPTIONS') {
  const origin = String(req.headers.origin || '').trim();
  if (!origin) return;
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', methods);
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Vary', 'Origin');
}

function parseCookies(req) {
  return String(req.headers.cookie || '').split(';').reduce((cookies, part) => {
    const index = part.indexOf('=');
    if (index < 0) return cookies;
    cookies[part.slice(0, index).trim()] = decodeURIComponent(part.slice(index + 1).trim());
    return cookies;
  }, {});
}

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(payload);
  return true;
}

function redirect(res, location) {
  res.writeHead(302, { Location: location, 'Cache-Control': 'no-store' });
  res.end();
}

function sendError(res, status, message) {
  return sendJson(res, status, { error: message });
}

function safeNext(value) {
  return ['/dashboard.html', '/journal.html', '/playbook.html', '/risk-tools.html', '/backtesting.html', '/referrals.html', '/settings.html'].includes(value) ? value : '/dashboard.html';
}

function readBody(req, maxBytes = 32 * 1024) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > maxBytes) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}
function referralCodeForUser(userId) {
  return `TV${Number(userId).toString(36).toUpperCase()}`;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

function verifyPassword(password, encoded) {
  const [algorithm, salt, expectedHex] = String(encoded || '').split(':');
  if (algorithm !== 'scrypt' || !salt || !expectedHex) return false;
  const actual = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  return expected.length === actual.length && crypto.timingSafeEqual(actual, expected);
}

function sessionToken() {
  return crypto.randomBytes(32).toString('base64url');
}

function tokenHash(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

async function createSession(req, res, userId) {
  const token = sessionToken();
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30);
  await db.execute('INSERT INTO tj_sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)', [tokenHash(token), userId, expiresAt]);
  setCookie(res, req, 'tj_session', token, 60 * 60 * 24 * 30);
}

async function currentUser(req) {
  const token = parseCookies(req).tj_session;
  if (!token) return null;
  const [rows] = await db.execute(`
    SELECT u.id, u.email, u.name, u.avatar_url, u.referral_code, u.reminder_enabled, u.reminder_hour, u.reminder_weekly_day, u.created_at
    FROM tj_sessions s JOIN tj_users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP()
    LIMIT 1
  `, [tokenHash(token)]);
  return rows[0] || null;
}

const tradeColumns = `id, pair, direction, entry, stop_loss, take_profit, exit_price, trade_date, trade_time, position_size, pnl, strategy, emotion, discipline, notes, planned_rr, realized_r, price_mode, stop_loss_pips, take_profit_pips, created_at`;

function formatTrade(row, imageStages = {}) {
  const realizedR = row.realized_r === null ? null : Number(row.realized_r);
  const plannedRR = row.planned_rr === null ? null : Number(row.planned_rr);
  const date = row.trade_date instanceof Date ? row.trade_date.toISOString().slice(0, 10) : String(row.trade_date).slice(0, 10);
  let outcome = 'open';
  if (realizedR !== null) outcome = realizedR > 0.05 ? 'win' : realizedR < -0.05 ? 'loss' : 'breakeven';
  return {
    id: row.id,
    pair: row.pair,
    direction: row.direction,
    entry: Number(row.entry),
    stopLoss: Number(row.stop_loss),
    takeProfit: row.take_profit === null ? null : Number(row.take_profit),
    exitPrice: row.exit_price === null ? null : Number(row.exit_price),
    date,
    notes: row.notes || '',
    positionSize: row.position_size === null ? null : Number(row.position_size),
    pnl: row.pnl === null ? null : Number(row.pnl),
    strategy: row.strategy || '',
    emotion: row.emotion || '',
    discipline: row.discipline || '',
    time: row.trade_time ? String(row.trade_time).slice(0, 5) : '',
    plannedRR,
    realizedR,
    priceMode: row.price_mode || 'price',
    pipUnit: instrumentSpec(row.pair).unit,
    stopLossPips: row.stop_loss_pips === null ? null : Number(row.stop_loss_pips),
    takeProfitPips: row.take_profit_pips === null ? null : Number(row.take_profit_pips),
    outcome,
    beforeImage: Boolean(imageStages.before),
    afterImage: Boolean(imageStages.after),
    createdAt: row.created_at,
  };
}


function instrumentSpec(pair) {
  const symbol = String(pair || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (/^(XAU|GOLD)/.test(symbol)) return { size: 0.01, decimals: 2, unit: 'points' };
  if (/^(XAG|SILVER)/.test(symbol)) return { size: 0.001, decimals: 3, unit: 'points' };
  if (/US30|DJI|NAS100|USTEC|SPX500|US500|GER40|DAX|UK100|FTSE/.test(symbol)) return { size: 1, decimals: 0, unit: 'points' };
  if (/JPY/.test(symbol)) return { size: 0.01, decimals: 3, unit: 'pips' };
  return { size: 0.0001, decimals: 5, unit: 'pips' };
}

function roundPrice(value) {
  return Number(Number(value).toFixed(8));
}

function parseTradePayload(body) {
  const pair = String(body.pair || '').trim().toUpperCase();
  const direction = body.direction === 'short' ? 'short' : body.direction === 'long' ? 'long' : '';
  const priceMode = body.priceMode === 'pips' ? 'pips' : 'price';
  const entry = Number(body.entry);
  const stopLossPips = body.stopLossPips === '' || body.stopLossPips === null || body.stopLossPips === undefined ? null : Number(body.stopLossPips);
  const takeProfitPips = body.takeProfitPips === '' || body.takeProfitPips === null || body.takeProfitPips === undefined ? null : Number(body.takeProfitPips);
  const spec = instrumentSpec(pair);
  let stopLoss = Number(body.stopLoss);
  let takeProfit = body.takeProfit === '' || body.takeProfit === null || body.takeProfit === undefined ? null : Number(body.takeProfit);
  if (priceMode === 'pips') {
    if (!Number.isFinite(stopLossPips) || stopLossPips <= 0) throw new Error(`Enter a positive stop-loss distance in ${spec.unit}.`);
    if (takeProfitPips !== null && (!Number.isFinite(takeProfitPips) || takeProfitPips <= 0)) throw new Error(`Take-profit distance must be positive ${spec.unit}.`);
    stopLoss = roundPrice(entry + (direction === 'short' ? 1 : -1) * stopLossPips * spec.size);
    takeProfit = takeProfitPips === null ? null : roundPrice(entry + (direction === 'short' ? -1 : 1) * takeProfitPips * spec.size);
  }
  const exitPrice = body.exitPrice === '' || body.exitPrice === null || body.exitPrice === undefined ? null : Number(body.exitPrice);
  const date = String(body.date || '').slice(0, 10);
  const notes = String(body.notes || '').trim().slice(0, 5000);
  const positionSize = body.positionSize === '' || body.positionSize === null || body.positionSize === undefined ? null : Number(body.positionSize);
  const pnl = body.pnl === '' || body.pnl === null || body.pnl === undefined ? null : Number(body.pnl);
  const strategy = String(body.strategy || '').trim().slice(0, 160);
  const emotion = String(body.emotion || '').trim().slice(0, 40);
  const discipline = String(body.discipline || '').trim().slice(0, 60);
  const time = String(body.time || '').trim();
  if (!pair || pair.length > 40) throw new Error('Enter a pair or symbol up to 40 characters.');
  if (!direction) throw new Error('Choose a trade direction.');
  if (![entry, stopLoss].every((value) => Number.isFinite(value))) throw new Error('Enter an entry price and stop loss.');
  if (entry === stopLoss) throw new Error('Entry and stop loss must be different.');
  if (direction === 'long' && stopLoss >= entry) throw new Error('For a long trade, stop loss must be below entry.');
  if (direction === 'short' && stopLoss <= entry) throw new Error('For a short trade, stop loss must be above entry.');
  if (takeProfit !== null && !Number.isFinite(takeProfit)) throw new Error('Take profit must be a valid number.');
  if (takeProfit !== null && ((direction === 'long' && takeProfit <= entry) || (direction === 'short' && takeProfit >= entry))) throw new Error('Take profit must be beyond entry in the trade direction.');
  if (exitPrice !== null && !Number.isFinite(exitPrice)) throw new Error('Exit price must be a valid number.');
  if (positionSize !== null && (!Number.isFinite(positionSize) || positionSize < 0)) throw new Error('Position size must be a valid non-negative number.');
  if (pnl !== null && !Number.isFinite(pnl)) throw new Error('P&L must be a valid number.');
  if (time && !/^\d{2}:\d{2}$/.test(time)) throw new Error('Trade time must use HH:MM format.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('Choose a valid trade date.');
  const risk = Math.abs(entry - stopLoss);
  const plannedRR = takeProfit === null ? null : Math.abs(takeProfit - entry) / risk;
  const realizedR = exitPrice === null ? null : ((exitPrice - entry) * (direction === 'short' ? -1 : 1)) / risk;
  return { pair, direction, entry, stopLoss, takeProfit, exitPrice, date, time: time || null, positionSize, pnl, strategy, emotion, discipline, notes, plannedRR, realizedR, priceMode, stopLossPips: priceMode === 'pips' ? stopLossPips : null, takeProfitPips: priceMode === 'pips' ? takeProfitPips : null };
}

async function requireUser(req, res) {
  const user = await currentUser(req);
  if (!user) {
    sendJson(res, 401, { error: 'Your session has expired. Please sign in again.' });
    return null;
  }
  return user;
}

async function handleReminderApi(req, res, pathname) {
  if (pathname !== '/api/reminders/status' || req.method !== 'GET') return false;
  const user = await requireUser(req, res);
  if (!user) return true;
  const [rows] = await db.execute(`
    SELECT t.id, t.pair, t.trade_date, t.trade_time,
           CASE WHEN a.trade_id IS NULL THEN 1 ELSE 0 END AS missing_after_image
    FROM tj_trades t
    LEFT JOIN (
      SELECT DISTINCT trade_id FROM tj_trade_images WHERE user_id = ? AND stage = 'after'
    ) a ON a.trade_id = t.id
    WHERE t.user_id = ? AND t.realized_r IS NULL
    ORDER BY t.trade_date ASC, t.id ASC
  `, [user.id, user.id]);
  const [missingRows] = await db.execute(`
    SELECT COUNT(*) AS total FROM tj_trades t
    LEFT JOIN (
      SELECT DISTINCT trade_id FROM tj_trade_images WHERE user_id = ? AND stage = 'after'
    ) a ON a.trade_id = t.id
    WHERE t.user_id = ? AND a.trade_id IS NULL AND t.trade_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
  `, [user.id, user.id]);
  const trades = rows.map((row) => ({ id: row.id, pair: row.pair, date: String(row.trade_date).slice(0, 10), time: row.trade_time || null, missingAfterImage: Boolean(row.missing_after_image) }));
  sendJson(res, 200, { openTrades: trades, openCount: trades.length, missingAfterCount: Number(missingRows[0]?.total || 0) });
  return true;
}
async function handleDashboardApi(req, res, pathname, url) {
  if (pathname !== '/api/dashboard/stats' || req.method !== 'GET') return false;
  const user = await requireUser(req, res);
  if (!user) return true;
  const params = url.searchParams;
  const from = /^\d{4}-\d{2}-\d{2}$/.test(params.get('from') || '') ? params.get('from') : null;
  const to = /^\d{4}-\d{2}-\d{2}$/.test(params.get('to') || '') ? params.get('to') : null;
  const month = /^\d{4}-\d{2}$/.test(params.get('month') || '') ? params.get('month') : new Date().toISOString().slice(0, 7);
  const conditions = ['user_id = ?']; const values = [user.id];
  if (from) { conditions.push('trade_date >= ?'); values.push(from); }
  if (to) { conditions.push('trade_date <= ?'); values.push(to); }
  const [rows] = await db.execute(`SELECT ${tradeColumns} FROM tj_trades WHERE ${conditions.join(' AND ')} ORDER BY trade_date ASC, id ASC`, values);
  const trades = rows.map(formatTrade);
  const closed = trades.filter((trade) => trade.realizedR !== null);
  const wins = closed.filter((trade) => trade.outcome === 'win').length;
  const losses = closed.filter((trade) => trade.outcome === 'loss').length;
  const totalR = closed.reduce((sum, trade) => sum + trade.realizedR, 0);
  const pnlTrades = closed.filter((trade) => trade.pnl !== null);
  const netPnl = pnlTrades.length ? pnlTrades.reduce((sum, trade) => sum + trade.pnl, 0) : null;
  const planned = trades.filter((trade) => trade.plannedRR !== null);
  let cumulativeR = 0;
  const equityCurve = closed.map((trade) => ({ date: trade.date, cumulativeR: Number((cumulativeR += trade.realizedR).toFixed(4)) }));
  const pairs = new Map(); trades.forEach((trade) => pairs.set(trade.pair, (pairs.get(trade.pair) || 0) + 1));
  const topPairs = [...pairs.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([pair, count]) => ({ pair, count }));
  const calendarByDate = new Map();
  trades.filter((trade) => trade.date.startsWith(`${month}-`)).forEach((trade) => {
    const day = calendarByDate.get(trade.date) || { date: trade.date, netR: null, netPnl: null, tradeCount: 0, pairs: [] };
    day.tradeCount += 1;
    if (!day.pairs.includes(trade.pair)) day.pairs.push(trade.pair);
    if (trade.realizedR !== null) day.netR = (day.netR || 0) + trade.realizedR;
    if (trade.realizedR !== null && trade.pnl !== null) day.netPnl = (day.netPnl || 0) + trade.pnl;
    calendarByDate.set(trade.date, day);
  });
  const calendar = [...calendarByDate.values()].map((day) => ({ ...day, netR: day.netR === null ? null : Number(day.netR.toFixed(4)), netPnl: day.netPnl === null ? null : Number(day.netPnl.toFixed(2)) }));
  const monthSummary = calendar.reduce((summary, day) => ({ netR: summary.netR + day.netR, netPnl: day.netPnl === null ? summary.netPnl : summary.netPnl + day.netPnl, hasPnl: summary.hasPnl || day.netPnl !== null }), { netR: 0, netPnl: 0, hasPnl: false });
  sendJson(res, 200, { stats: { totalR, netPnl, pnlTracked: pnlTrades.length, closedTrades: closed.length, winRate: closed.length ? (wins / closed.length) * 100 : 0, wins, losses, expectancyR: closed.length ? totalR / closed.length : null, avgPlannedRR: planned.length ? planned.reduce((sum, trade) => sum + trade.plannedRR, 0) / planned.length : null, totalTrades: trades.length, openTrades: trades.length - closed.length, equityCurve, topPairs, calendar, month, monthSummary } });
  return true;
}
async function handleJournalApi(req, res, pathname) {
  if (!pathname.startsWith('/api/journal')) return false;
  allowCrossOrigin(req, res, 'GET, POST, PUT, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return true;
  }
  const user = await requireUser(req, res);
  if (!user) return true;
  const imageMatch = pathname.match(/^\/api\/journal\/(\d+)\/images\/(before|after)$/);
  if (imageMatch) {
    const tradeId = Number(imageMatch[1]);
    const stage = imageMatch[2];
    const [ownedTrade] = await db.execute('SELECT id FROM tj_trades WHERE id = ? AND user_id = ? LIMIT 1', [tradeId, user.id]);
    if (!ownedTrade[0]) return sendError(res, 404, 'Trade not found.');
    if (req.method === 'GET') {
      const [rows] = await db.execute('SELECT mime_type, image_data FROM tj_trade_images WHERE trade_id = ? AND user_id = ? AND stage = ? LIMIT 1', [tradeId, user.id, stage]);
      if (!rows[0]) return sendError(res, 404, 'Trade image not found.');
      res.writeHead(200, { 'Content-Type': rows[0].mime_type, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
      res.end(rows[0].image_data);
      return true;
    }
    if (req.method === 'POST') {
      try {
        const body = await readBody(req, 8 * 1024 * 1024);
        const allowedTypes = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
        const mimeType = String(body.mimeType || '').toLowerCase();
        const encoded = String(body.data || '').replace(/^data:[^;]+;base64,/, '');
        if (!allowedTypes.has(mimeType)) throw new Error('Use a JPG, PNG, WebP, or GIF image.');
        if (!/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) throw new Error('The selected image could not be read.');
        const imageData = Buffer.from(encoded, 'base64');
        if (!imageData.length || imageData.length > 5 * 1024 * 1024) throw new Error('Images must be 5 MB or smaller.');
        const fileName = String(body.fileName || `${stage}-trade-image`).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 160);
        const [updated] = await db.execute('UPDATE tj_trade_images SET mime_type = ?, file_name = ?, image_data = ?, created_at = CURRENT_TIMESTAMP WHERE trade_id = ? AND user_id = ? AND stage = ?', [mimeType, fileName, imageData, tradeId, user.id, stage]);
        if (!updated.affectedRows) {
          try {
            await db.execute('INSERT INTO tj_trade_images (trade_id, user_id, stage, mime_type, file_name, image_data) VALUES (?, ?, ?, ?, ?, ?)', [tradeId, user.id, stage, mimeType, fileName, imageData]);
          } catch (insertError) {
            if (insertError.code !== 'ER_DUP_ENTRY') throw insertError;
            await db.execute('UPDATE tj_trade_images SET mime_type = ?, file_name = ?, image_data = ?, created_at = CURRENT_TIMESTAMP WHERE trade_id = ? AND user_id = ? AND stage = ?', [mimeType, fileName, imageData, tradeId, user.id, stage]);
          }
        }
        sendJson(res, 200, { ok: true, stage, url: `/api/journal/${tradeId}/images/${stage}` });
      } catch (error) {
        sendError(res, 400, error.message);
      }
      return true;
    }
    if (req.method === 'DELETE') {
      await db.execute('DELETE FROM tj_trade_images WHERE trade_id = ? AND user_id = ? AND stage = ?', [tradeId, user.id, stage]);
      sendJson(res, 200, { ok: true });
      return true;
    }
    return sendError(res, 405, 'Method not allowed.');
  }
  const match = pathname.match(/^\/api\/journal\/(\d+)$/);
  if (pathname === '/api/journal' && req.method === 'GET') {
    const [rows] = await db.execute(`SELECT ${tradeColumns} FROM tj_trades WHERE user_id = ? ORDER BY trade_date DESC, id DESC`, [user.id]);
    const [imageRows] = await db.execute('SELECT trade_id, stage FROM tj_trade_images WHERE user_id = ?', [user.id]);
    const images = imageRows.reduce((map, row) => { map[row.trade_id] = map[row.trade_id] || {}; map[row.trade_id][row.stage] = true; return map; }, {});
    sendJson(res, 200, { trades: rows.map((row) => formatTrade(row, images[row.id] || {})) });
    return true;
  }
  if (pathname === '/api/journal' && req.method === 'POST') {
    try {
      const trade = parseTradePayload(await readBody(req));
      const [result] = await db.execute(`INSERT INTO tj_trades (user_id, pair, direction, entry, stop_loss, take_profit, exit_price, trade_date, trade_time, position_size, pnl, strategy, emotion, discipline, notes, planned_rr, realized_r, price_mode, stop_loss_pips, take_profit_pips) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [user.id, trade.pair, trade.direction, trade.entry, trade.stopLoss, trade.takeProfit, trade.exitPrice, trade.date, trade.time, trade.positionSize, trade.pnl, trade.strategy, trade.emotion, trade.discipline, trade.notes, trade.plannedRR, trade.realizedR, trade.priceMode, trade.stopLossPips, trade.takeProfitPips]);
      const [rows] = await db.execute(`SELECT ${tradeColumns} FROM tj_trades WHERE id = ? AND user_id = ?`, [result.insertId, user.id]);
      sendJson(res, 201, { trade: formatTrade(rows[0]) });
    } catch (error) {
      sendError(res, 400, error.message);
    }
    return true;
  }
  if (!match) return sendError(res, 404, 'Journal route not found.');
  const tradeId = Number(match[1]);
  if (req.method === 'PUT') {
    try {
      const trade = parseTradePayload(await readBody(req));
      const [result] = await db.execute(`UPDATE tj_trades SET pair = ?, direction = ?, entry = ?, stop_loss = ?, take_profit = ?, exit_price = ?, trade_date = ?, trade_time = ?, position_size = ?, pnl = ?, strategy = ?, emotion = ?, discipline = ?, notes = ?, planned_rr = ?, realized_r = ?, price_mode = ?, stop_loss_pips = ?, take_profit_pips = ? WHERE id = ? AND user_id = ?`, [trade.pair, trade.direction, trade.entry, trade.stopLoss, trade.takeProfit, trade.exitPrice, trade.date, trade.time, trade.positionSize, trade.pnl, trade.strategy, trade.emotion, trade.discipline, trade.notes, trade.plannedRR, trade.realizedR, trade.priceMode, trade.stopLossPips, trade.takeProfitPips, tradeId, user.id]);
      if (!result.affectedRows) return sendError(res, 404, 'Trade not found.');
      const [rows] = await db.execute(`SELECT ${tradeColumns} FROM tj_trades WHERE id = ? AND user_id = ?`, [tradeId, user.id]);
      sendJson(res, 200, { trade: formatTrade(rows[0]) });
    } catch (error) {
      sendError(res, 400, error.message);
    }
    return true;
  }
  if (req.method === 'DELETE') {
    const [result] = await db.execute('DELETE FROM tj_trades WHERE id = ? AND user_id = ?', [tradeId, user.id]);
    if (!result.affectedRows) return sendError(res, 404, 'Trade not found.');
    sendJson(res, 200, { ok: true });
    return true;
  }
  return sendError(res, 405, 'Method not allowed.');
}

async function initDatabase() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not available');
  db = mysql.createPool({
    uri: process.env.DATABASE_URL,
    waitForConnections: true,
    connectionLimit: 5,
    ssl: { minVersion: 'TLSv1.2' },
  });
  await db.query(`
    CREATE TABLE IF NOT EXISTS tj_users (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(320) NOT NULL UNIQUE,
      name VARCHAR(120) NOT NULL,
      password_hash VARCHAR(255) NULL,
      google_sub VARCHAR(255) NULL UNIQUE,
      avatar_url TEXT NULL,
      referral_code VARCHAR(32) NULL UNIQUE,
      referred_by BIGINT UNSIGNED NULL,
      reminder_enabled TINYINT(1) NOT NULL DEFAULT 1,
      reminder_hour TINYINT UNSIGNED NOT NULL DEFAULT 18,
      reminder_weekly_day TINYINT UNSIGNED NOT NULL DEFAULT 0,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
  for (const [column, definition] of [['referral_code', 'VARCHAR(32) NULL'], ['referred_by', 'BIGINT UNSIGNED NULL'], ['reminder_enabled', 'TINYINT(1) NOT NULL DEFAULT 1'], ['reminder_hour', 'TINYINT UNSIGNED NOT NULL DEFAULT 18'], ['reminder_weekly_day', 'TINYINT UNSIGNED NOT NULL DEFAULT 0']]) {
    try { await db.query(`ALTER TABLE tj_users ADD COLUMN ${column} ${definition}`); }
    catch (error) { if (error.code !== 'ER_DUP_FIELDNAME') throw error; }
  }
  await db.query("UPDATE tj_users SET referral_code = CONCAT('TV', UPPER(CONV(id, 10, 36))) WHERE referral_code IS NULL");
  await db.query(`
    CREATE TABLE IF NOT EXISTS tj_sessions (
      token_hash CHAR(64) NOT NULL PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_tj_sessions_user (user_id),
      CONSTRAINT fk_tj_sessions_user FOREIGN KEY (user_id) REFERENCES tj_users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS tj_trades (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      pair VARCHAR(40) NOT NULL,
      direction ENUM('long','short') NOT NULL,
      entry DECIMAL(20,8) NOT NULL,
      stop_loss DECIMAL(20,8) NOT NULL,
      take_profit DECIMAL(20,8) NULL,
      exit_price DECIMAL(20,8) NULL,
      trade_date DATE NOT NULL,
      notes TEXT NULL,
      planned_rr DECIMAL(20,8) NULL,
      realized_r DECIMAL(20,8) NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_tj_trades_user_date (user_id, trade_date),
      CONSTRAINT fk_tj_trades_user FOREIGN KEY (user_id) REFERENCES tj_users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
  for (const [column, definition] of optionalTradeColumns) {
    try { await db.query(`ALTER TABLE tj_trades ADD COLUMN ${column} ${definition}`); }
    catch (error) { if (error.code !== 'ER_DUP_FIELDNAME') throw error; }
  }
  await db.query(`
    CREATE TABLE IF NOT EXISTS tj_trade_images (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      trade_id BIGINT UNSIGNED NOT NULL,
      user_id BIGINT UNSIGNED NOT NULL,
      stage ENUM('before','after') NOT NULL,
      mime_type VARCHAR(64) NOT NULL,
      file_name VARCHAR(160) NOT NULL,
      image_data MEDIUMBLOB NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_tj_trade_image_stage (trade_id, stage),
      INDEX idx_tj_trade_images_user (user_id),
      CONSTRAINT fk_tj_trade_images_trade FOREIGN KEY (trade_id) REFERENCES tj_trades(id) ON DELETE CASCADE,
      CONSTRAINT fk_tj_trade_images_user FOREIGN KEY (user_id) REFERENCES tj_users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
}

async function handleReferralApi(req, res, pathname) {
  if (pathname !== '/api/referrals/me') return false;
  allowCrossOrigin(req, res, 'GET, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return true; }
  if (req.method !== 'GET') return sendError(res, 405, 'Method not allowed.');
  const user = await requireUser(req, res);
  if (!user) return true;
  let code = user.referral_code;
  if (!code) {
    code = referralCodeForUser(user.id);
    await db.execute('UPDATE tj_users SET referral_code = ? WHERE id = ?', [code, user.id]);
  }
  const [rows] = await db.execute('SELECT id, name, email, created_at FROM tj_users WHERE referred_by = ? ORDER BY created_at DESC', [user.id]);
  sendJson(res, 200, {
    referralCode: code,
    signUps: rows.length,
    referredTraders: rows.length,
    totalRewards: null,
    pendingRewards: null,
    referrals: rows.map((row) => ({ id: row.id, name: row.name, email: row.email, joinedAt: row.created_at })),
  });
  return true;
}
async function handleSettingsApi(req, res, pathname) {
  if (!pathname.startsWith('/api/settings')) return false;
  allowCrossOrigin(req, res, 'GET, PUT, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return true; }
  const user = await requireUser(req, res);
  if (!user) return true;
  if (pathname === '/api/settings' && req.method === 'GET') {
    sendJson(res, 200, { user: { id: user.id, name: user.name, email: user.email, createdAt: user.created_at }, preferences: { remindersEnabled: Boolean(user.reminder_enabled), reminderHour: Number(user.reminder_hour ?? 18), weeklyDay: Number(user.reminder_weekly_day ?? 0) }, billing: { plan: 'Basic', status: 'Active' } });
    return true;
  }
  if (pathname === '/api/settings' && req.method === 'PUT') {
    try {
      const body = await readBody(req);
      const name = body.name === undefined ? user.name : String(body.name || '').trim();
      const reminderHour = body.reminderHour === undefined ? Number(user.reminder_hour ?? 18) : Number(body.reminderHour);
      const weeklyDay = body.weeklyDay === undefined ? Number(user.reminder_weekly_day ?? 0) : Number(body.weeklyDay);
      const remindersEnabled = body.remindersEnabled === undefined ? Boolean(user.reminder_enabled) : Boolean(body.remindersEnabled);
      if (name.length < 2 || name.length > 120) throw new Error('Enter a name between 2 and 120 characters.');
      if (!Number.isInteger(reminderHour) || reminderHour < 0 || reminderHour > 23) throw new Error('Choose a reminder hour between 00:00 and 23:00.');
      if (!Number.isInteger(weeklyDay) || weeklyDay < 0 || weeklyDay > 6) throw new Error('Choose a valid weekly review day.');
      await db.execute('UPDATE tj_users SET name = ?, reminder_enabled = ?, reminder_hour = ?, reminder_weekly_day = ? WHERE id = ?', [name, remindersEnabled ? 1 : 0, reminderHour, weeklyDay, user.id]);
      sendJson(res, 200, { ok: true, user: { name }, preferences: { remindersEnabled, reminderHour, weeklyDay } });
    } catch (error) { sendError(res, 400, error.message); }
    return true;
  }
  if (pathname === '/api/settings/password' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      const currentPassword = String(body.currentPassword || '');
      const newPassword = String(body.newPassword || '');
      const [rows] = await db.execute('SELECT password_hash FROM tj_users WHERE id = ? LIMIT 1', [user.id]);
      const existingHash = rows[0]?.password_hash;
      if (existingHash && !verifyPassword(currentPassword, existingHash)) throw new Error('Your current password is not correct.');
      if (newPassword.length < 8) throw new Error('Use at least 8 characters for your new password.');
      await db.execute('UPDATE tj_users SET password_hash = ? WHERE id = ?', [hashPassword(newPassword), user.id]);
      sendJson(res, 200, { ok: true });
    } catch (error) { sendError(res, 400, error.message); }
    return true;
  }
  return sendError(res, 404, 'Settings route not found.');
}
async function handleAuthApi(req, res, pathname, url) {
  if (pathname.startsWith('/api/auth/')) {
    allowCrossOrigin(req, res);
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return true;
    }
  }

  if (pathname.startsWith('/api/auth/') && !['GET', 'POST'].includes(req.method)) {
    sendError(res, 405, 'Method not allowed.');
    return true;
  }

  if (pathname === '/api/auth/me' && req.method === 'GET') {
    const user = await currentUser(req);
    sendJson(res, 200, { authenticated: Boolean(user), user });
    return true;
  }

  if (pathname === '/api/auth/logout' && req.method === 'POST') {
    const token = parseCookies(req).tj_session;
    if (token) await db.execute('DELETE FROM tj_sessions WHERE token_hash = ?', [tokenHash(token)]);
    setCookie(res, req, 'tj_session', '', 0);
    sendJson(res, 200, { ok: true });
    return true;
  }

  if ((pathname === '/api/auth/signup' || pathname === '/api/auth/login') && req.method === 'POST') {
    const body = await readBody(req);
    const email = normalizeEmail(body.email);
    const password = String(body.password || '');
    const name = String(body.name || '').trim();
    const next = safeNext(body.next);

    if (!email || email.length > 320 || /[\s\u0000-\u001f\u007f]/.test(email)) return sendError(res, 400, 'Enter an email address.');
    if (pathname.endsWith('signup')) {
      if (name.length < 2 || name.length > 120) return sendError(res, 400, 'Enter your name so your journal has an owner.');
      if (password.length < 8) return sendError(res, 400, 'Use at least 8 characters for your password.');
      try {
        const referralCode = String(body.referralCode || '').trim().toUpperCase().slice(0, 32);
        let referrerId = null;
        if (referralCode) {
          const [referrers] = await db.execute('SELECT id FROM tj_users WHERE referral_code = ? LIMIT 1', [referralCode]);
          referrerId = referrers[0]?.id || null;
        }
        const [result] = await db.execute('INSERT INTO tj_users (email, name, password_hash, referred_by) VALUES (?, ?, ?, ?)', [email, name, hashPassword(password), referrerId]);
        const generatedCode = referralCodeForUser(result.insertId);
        await db.execute('UPDATE tj_users SET referral_code = ? WHERE id = ?', [generatedCode, result.insertId]);
        await createSession(req, res, result.insertId);
        sendJson(res, 201, { ok: true, redirect: next });
      } catch (error) {
        if (error && error.code === 'ER_DUP_ENTRY') return sendError(res, 409, 'An account with that email already exists. Try signing in instead.');
        throw error;
      }
      return true;
    }

    if (!password) return sendError(res, 400, 'Enter your password.');
    const [rows] = await db.execute('SELECT id, password_hash FROM tj_users WHERE email = ? LIMIT 1', [email]);
    const user = rows[0];
    if (!user || !user.password_hash || !verifyPassword(password, user.password_hash)) return sendError(res, 401, 'Email or password not recognized.');
    await createSession(req, res, user.id);
    sendJson(res, 200, { ok: true, redirect: next });
    return true;
  }

  return false;
}

async function handleGoogle(req, res, pathname, url) {
  if (pathname === '/auth/google' && req.method === 'GET') {
    if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
      redirect(res, '/login.html?error=google_unavailable');
      return true;
    }
    const state = crypto.randomBytes(24).toString('hex');
    const nonce = crypto.randomBytes(24).toString('hex');
    setCookie(res, req, 'tj_google_state', `${state}.${nonce}`, 600);
    const callback = `${publicOrigin(req)}/auth/google/callback`;
    const googleUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    googleUrl.search = new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID,
      redirect_uri: callback,
      response_type: 'code',
      scope: 'openid email profile',
      state,
      nonce,
      prompt: 'select_account',
    }).toString();
    redirect(res, googleUrl.toString());
    return true;
  }

  if (pathname === '/auth/google/callback' && req.method === 'GET') {
    const cookies = parseCookies(req);
    const expected = cookies.tj_google_state || '';
    setCookie(res, req, 'tj_google_state', '', 0);
    if (!url.searchParams.get('code') || !url.searchParams.get('state') || url.searchParams.get('state') !== expected.split('.')[0]) {
      redirect(res, '/login.html?error=google_state');
      return true;
    }
    try {
      const callback = `${publicOrigin(req)}/auth/google/callback`;
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code: url.searchParams.get('code'),
          client_id: process.env.GOOGLE_CLIENT_ID,
          client_secret: process.env.GOOGLE_CLIENT_SECRET,
          redirect_uri: callback,
          grant_type: 'authorization_code',
        }),
      });
      if (!tokenResponse.ok) throw new Error(`Google token exchange failed: ${tokenResponse.status}`);
      const tokens = await tokenResponse.json();
      const profileResponse = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      if (!profileResponse.ok) throw new Error(`Google profile lookup failed: ${profileResponse.status}`);
      const profile = await profileResponse.json();
      const email = normalizeEmail(profile.email);
      if (!profile.sub || !email || profile.email_verified !== true) throw new Error('Google did not return a verified email.');

      const [existingRows] = await db.execute('SELECT id FROM tj_users WHERE google_sub = ? OR email = ? LIMIT 1', [profile.sub, email]);
      let userId;
      if (existingRows[0]) {
        userId = existingRows[0].id;
        await db.execute('UPDATE tj_users SET google_sub = ?, name = ?, avatar_url = ? WHERE id = ?', [profile.sub, String(profile.name || email.split('@')[0]).slice(0, 120), profile.picture || null, userId]);
      } else {
        const [result] = await db.execute('INSERT INTO tj_users (email, name, google_sub, avatar_url) VALUES (?, ?, ?, ?)', [email, String(profile.name || email.split('@')[0]).slice(0, 120), profile.sub, profile.picture || null]);
        userId = result.insertId;
      }
      await createSession(req, res, userId);
      redirect(res, '/dashboard.html');
    } catch (error) {
      console.error('Google OAuth error:', error.message);
      redirect(res, '/login.html?error=google_failed');
    }
    return true;
  }

  return false;
}

function serveStatic(req, res, pathname) {
  const requested = pathname || '/';
  const fileName = requested === '/' ? 'index.html' : requested.replace(/^\/+/, '');
  const rootPath = path.resolve(root);
  const filePath = path.resolve(rootPath, fileName);
  if (filePath !== rootPath && !filePath.startsWith(`${rootPath}${path.sep}`)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }
  fs.stat(filePath, (error, stats) => {
    if (error || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': mime[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': path.extname(filePath) === '.webp' ? 'public, max-age=31536000, immutable' : 'no-cache',
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname || '/');
  } catch {
    sendError(res, 400, 'Invalid URL.');
    return;
  }
  try {
    if (await handleAuthApi(req, res, pathname, url)) return;
    if (await handleReferralApi(req, res, pathname)) return;
    if (await handleSettingsApi(req, res, pathname)) return;
    if (await handleReminderApi(req, res, pathname)) return;
    if (await handleDashboardApi(req, res, pathname, url)) return;
    if (await handleJournalApi(req, res, pathname)) return;
    if (await handleGoogle(req, res, pathname, url)) return;
    if (['/dashboard.html', '/journal.html', '/playbook.html', '/risk-tools.html', '/backtesting.html', '/settings.html'].includes(pathname) && ['GET', 'HEAD'].includes(req.method)) {
      const user = await currentUser(req);
      if (!user) {
        redirect(res, `/signup.html?next=${encodeURIComponent(pathname)}`);
        return;
      }
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendError(res, 405, 'Method not allowed.');
      return;
    }
    serveStatic(req, res, pathname);
  } catch (error) {
    console.error('Request error:', error);
    if (!res.headersSent) sendError(res, 500, 'Something went wrong. Please try again.');
  }
});

initDatabase()
  .then(() => server.listen(port, '0.0.0.0', () => console.log(`Trade Vera app listening on 0.0.0.0:${port}`)))
  .catch((error) => {
    console.error('Database initialization failed:', error);
    process.exit(1);
  });
