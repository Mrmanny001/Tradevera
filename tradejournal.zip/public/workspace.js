(() => {
  const setUser = (user) => {
    document.querySelectorAll('[data-user-name]').forEach((el) => { el.textContent = user?.name || 'Trader'; });
    document.querySelectorAll('[data-user-email]').forEach((el) => { el.textContent = user?.email || ''; });
    document.querySelectorAll('[data-user-avatar]').forEach((el) => { el.textContent = (user?.name || 'T').trim().charAt(0).toUpperCase(); });
  };
  const showToast = (message, type = '') => {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    window.setTimeout(() => toast.remove(), 3600);
  };
  const api = async (path, options = {}) => {
    const response = await fetch(path, { credentials: 'include', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options });
    let data = {};
    try { data = await response.json(); } catch {}
    if (response.status === 401) { window.location.assign('/login.html?error=session_unavailable'); throw new Error(data.error || 'Please sign in again.'); }
    if (!response.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
    return data;
  };
  window.TJ = { api, showToast, ready: null, user: null };
  document.querySelectorAll('[data-menu-toggle]').forEach((button) => button.addEventListener('click', () => { document.querySelector('.sidebar')?.classList.toggle('open'); document.querySelector('.sidebar-scrim')?.classList.toggle('show'); }));
  const profileTrigger = document.querySelector('.dashboard-profile-trigger');
  const profileMenu = document.getElementById('dashboard-profile-menu');
  const closeProfileMenu = () => { if (!profileMenu || !profileTrigger) return; profileMenu.hidden = true; profileTrigger.setAttribute('aria-expanded', 'false'); };
  profileTrigger?.addEventListener('click', () => { const isOpen = !profileMenu.hidden; profileMenu.hidden = isOpen; profileTrigger.setAttribute('aria-expanded', String(!isOpen)); });
  document.addEventListener('click', (event) => { if (profileMenu && profileTrigger && !event.target.closest('.dashboard-account-card')) closeProfileMenu(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeProfileMenu(); });
  document.querySelector('.sidebar-scrim')?.addEventListener('click', () => { document.querySelector('.sidebar')?.classList.remove('open'); document.querySelector('.sidebar-scrim')?.classList.remove('show'); });
  document.querySelectorAll('[data-logout]').forEach((button) => button.addEventListener('click', async () => { try { await api('/api/auth/logout', { method: 'POST', body: '{}' }); } finally { window.location.assign('/'); } }));
  TJ.ready = api('/api/auth/me').then(({ user }) => { TJ.user = user; setUser(user); return user; }).catch((error) => { showToast(error.message, 'error'); throw error; });
})();
