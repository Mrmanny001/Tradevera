(() => {
  const STORAGE_KEY = 'trade-vera-theme';
  const root = document.documentElement;
  const pageDefault = document.body?.dataset.themeDefault || 'light';
  const stored = (() => { try { return localStorage.getItem(STORAGE_KEY); } catch { return null; } })();

  const applyTheme = (theme) => {
    const next = theme === 'dark' ? 'dark' : 'light';
    root.dataset.theme = next;
    document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
      const isDark = next === 'dark';
      button.setAttribute('aria-pressed', String(isDark));
      button.setAttribute('aria-label', `Switch to ${isDark ? 'light' : 'dark'} mode`);
      button.querySelector('[data-theme-label]')?.replaceChildren(document.createTextNode(isDark ? 'Light' : 'Dark'));
    });
  };

  applyTheme(stored || root.dataset.theme || pageDefault);
  document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem(STORAGE_KEY, next); } catch {}
      applyTheme(next);
    });
  });
})();
