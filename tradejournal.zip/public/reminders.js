(() => {
  const banner = document.querySelector('[data-page="dashboard"] #trade-reminder');
  const enableButton = document.querySelector('[data-enable-reminders]');
  const title = document.querySelector('[data-reminder-title]');
  const message = document.querySelector('[data-reminder-message]');
  const storageKey = 'trade-vera-reminders';
  let dueHour = Number(localStorage.getItem('trade-vera-reminder-hour') || 18);
  let remindersEnabled = localStorage.getItem('trade-vera-reminders-enabled') !== 'false';
  let weeklyDay = Number(localStorage.getItem('trade-vera-reminder-weekly-day') || 0);
  const dateKey = (date) => date.toISOString().slice(0, 10);
  const localDateKey = (date) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const weekday = (date) => date.getDay();
  const getSeen = () => { try { return JSON.parse(localStorage.getItem(storageKey) || '{}'); } catch { return {}; } };
  const setSeen = (key) => { try { const seen = getSeen(); seen[key] = Date.now(); localStorage.setItem(storageKey, JSON.stringify(seen)); } catch {} };
  const nextDue = (now) => {
    const candidate = new Date(now);
    candidate.setHours(dueHour, 0, 0, 0);
    for (let i = 0; i < 8; i += 1) {
      const day = candidate.getDay();
      const isDaily = day >= 1 && day <= 5;
      const isWeekly = day === weeklyDay;
      if ((isDaily || isWeekly) && candidate > now) return { date: candidate, type: isWeekly ? 'weekly' : 'daily' };
      candidate.setDate(candidate.getDate() + 1);
      candidate.setHours(dueHour, 0, 0, 0);
    }
    return null;
  };
  const currentDue = (now) => {
    const day = now.getDay();
    if (now.getHours() < dueHour || (day === 0 || day >= 6) && day !== 0) return null;
    if (day >= 1 && day <= 5) return { type: 'daily', key: `daily-${localDateKey(now)}` };
    if (day === weeklyDay) return { type: 'weekly', key: `weekly-${localDateKey(now)}` };
    return null;
  };
  const notify = (status, due) => {
    if (!remindersEnabled || !due || !status.openCount || getSeen()[due.key]) return;
    const suffix = status.missingAfterCount ? ` ${status.missingAfterCount} trade${status.missingAfterCount === 1 ? '' : 's'} still need${status.missingAfterCount === 1 ? 's' : ''} an after image.` : ' Add your after-trade notes or image while the decision is fresh.';
    const body = `${status.openCount} open trade${status.openCount === 1 ? '' : 's'} to review.${suffix}`;
    if ('Notification' in window && Notification.permission === 'granted') new Notification('Trade Vera review reminder', { body, tag: due.key });
    setSeen(due.key);
  };
  const render = (status) => {
    if (!banner) return;
    if (!status.openCount) { banner.hidden = true; return; }
    banner.hidden = false;
    const imageText = status.missingAfterCount ? ` ${status.missingAfterCount} still need${status.missingAfterCount === 1 ? 's' : ''} an after image.` : '';
    title.textContent = `${status.openCount} open trade${status.openCount === 1 ? '' : 's'} need a quick review.`;
    message.textContent = `Add your after-trade context before it gets lost.${imageText}`;
  };
  const schedule = (status) => {
    const now = new Date();
    notify(status, currentDue(now));
    const upcoming = nextDue(now);
    if (upcoming) window.setTimeout(() => { notify(status, { type: upcoming.type, key: `${upcoming.type}-${localDateKey(upcoming.date)}` }); }, Math.max(1000, upcoming.date.getTime() - now.getTime()));
  };
  const load = async () => {
    if (!window.TJ?.ready) return;
    try {
      const [status, settings] = await Promise.all([TJ.api('/api/reminders/status'), TJ.api('/api/settings')]);
      dueHour = Number(settings.preferences.reminderHour ?? dueHour);
      remindersEnabled = Boolean(settings.preferences.remindersEnabled);
      weeklyDay = Number(settings.preferences.weeklyDay ?? weeklyDay);
      localStorage.setItem('trade-vera-reminder-hour', String(dueHour));
      localStorage.setItem('trade-vera-reminders-enabled', String(remindersEnabled));
      localStorage.setItem('trade-vera-reminder-weekly-day', String(weeklyDay));
      render(status);
      if (remindersEnabled) schedule(status);
    } catch {}
  };
  enableButton?.addEventListener('click', async () => {
    if (!('Notification' in window)) { if (window.TJ) TJ.showToast('Browser notifications are not supported here.', 'error'); return; }
    const permission = await Notification.requestPermission();
    if (permission === 'granted') { enableButton.textContent = 'Browser reminders enabled'; enableButton.disabled = true; load(); }
    else if (window.TJ) TJ.showToast('Notifications remain off. You can enable them in browser settings.', 'error');
  });
  window.setTimeout(load, 0);
})();
