(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const CANDLE_LIMIT = 1000;
  const API_BASE = 'https://data-api.binance.vision/api/v3/klines';
  const STREAM_BASE = 'wss://stream.binance.com:443/ws';
  const COLORS_KEY = 'tradevera.backtesting.replay.colors.v1';
  const FAVORITES_KEY = 'tradevera.backtesting.replay.favorites.v1';
  const DRAWINGS_KEY = 'tradevera.backtesting.replay.drawings.v1';
  const STUDIES_KEY = 'tradevera.backtesting.chart.studies.v1';
  const DEFAULT_COLORS = { up: '#169b73', down: '#df6157' };
  const TOOL_LABELS = { trendline: 'Trend line', horizontal: 'Horizontal line', vertical: 'Vertical line', rectangle: 'Rectangle' };
  const state = {
    chart: null, priceSeries: null, candles: null, volume: null, sma20: null, sma50: null,
    bars: [], liveBar: null, cursor: 0, playing: false, timer: 0,
    request: null, socket: null, reconnectTimer: 0, retrievedAt: null,
    mode: 'live', symbol: 'BTCUSDT', interval: '15m', chartType: 'candles',
    favoriteTools: ['trendline', 'horizontal', 'rectangle'], activeTool: 'cursor',
    colors: { ...DEFAULT_COLORS }, studies: { sma20: false, sma50: false, volume: true },
    drawings: [], draft: null, followingLive: true,
  };

  const el = {
    host: $('#replay-chart-host'), wrap: $('#replay-chart-wrap'), status: $('#replay-data-status'),
    symbol: $('#replay-symbol'), interval: $('#replay-interval'), chartType: $('#chart-type'),
    marketLabel: $('#replay-market-label'), marketSource: $('#replay-market-source'),
    open: $('#replay-open'), high: $('#replay-high'), low: $('#replay-low'), close: $('#replay-close'), candleTime: $('#replay-candle-time'),
    sourceLine: $('#replay-data-line'), connection: $('#chart-connection-status'),
    scrubber: $('#replay-scrubber'), startTime: $('#replay-start-time'), endTime: $('#replay-end-time'),
    progressLabel: $('#replay-progress-label'), progressFill: $('#replay-progress-fill'), selectedLabel: $('#replay-selected-label'),
    speed: $('#replay-speed'), player: $('#replay-player'), play: $('#replay-play'), selectionBanner: $('#replay-selection-banner'),
    replayToggle: $('#replay-mode-toggle'), replayLabel: $('#replay-mode-label'),
    drawingLayer: $('#replay-drawing-layer'), favorites: $('#replay-favorites'), activeToolLabel: $('#replay-active-tool'),
    upColor: $('#replay-up-color'), downColor: $('#replay-down-color'), styleToggle: $('#replay-style-toggle'), stylePopover: $('#replay-style-popover'),
    favoritesToggle: $('#replay-favorites-toggle'), favoritesPopover: $('#replay-favorites-popover'), selectTool: $('#replay-select-tool'),
    studiesToggle: $('#chart-indicators-toggle'), studiesPopover: $('#chart-indicators-popover'), studyCount: $('#study-count'), studyLegend: $('#study-legend'),
    settingsToggle: $('#chart-settings-toggle'), settingsPopover: $('#chart-settings-popover'), volumeToggle: $('#chart-volume-toggle'),
  };

  function safeRead(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || 'null') ?? fallback; } catch { return fallback; }
  }
  function safeWrite(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
  }
  function symbolLabel(symbol = el.symbol.value) {
    return ({ BTCUSDT: 'BTC / USDT', ETHUSDT: 'ETH / USDT', SOLUSDT: 'SOL / USDT' })[symbol] || symbol;
  }
  function intervalToTv(value) {
    return ({ '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '2h': '120', '4h': '240', '1d': 'D' })[value] || '15';
  }
  function intervalFromTv(value) {
    return ({ '1': '1m', '3': '3m', '5': '5m', '15': '15m', '30': '30m', '60': '1h', '120': '2h', '240': '4h', D: '1d', '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '2h': '2h', '4h': '4h', '1d': '1d' })[value] || '15m';
  }
  function priceFormat(value) {
    const digits = state.symbol === 'SOLUSDT' ? 3 : state.symbol.endsWith('BTCUSDT') ? 2 : 2;
    return Number(value).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
  }
  function utcTime(value, includeDate = true) {
    if (value == null) return '—';
    const date = new Date(Number(value) * 1000);
    if (Number.isNaN(date.getTime())) return '—';
    return new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', ...(includeDate ? { year: 'numeric', month: 'short', day: '2-digit' } : {}), hour: '2-digit', minute: '2-digit', hour12: false }).format(date) + ' UTC';
  }
  function retrievalTime(date = new Date()) {
    return new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(date) + ' UTC';
  }
  function setStatus(message, error = false) {
    if (!el.status) return;
    el.status.classList.toggle('is-error', error);
    el.status.hidden = false;
    el.status.replaceChildren(document.createTextNode(message));
    if (error) {
      const retry = document.createElement('button');
      retry.type = 'button'; retry.className = 'bt-replay-retry'; retry.textContent = 'Try again';
      retry.addEventListener('click', () => loadBars());
      el.status.append(document.createElement('br'), retry);
    }
  }
  function clearStatus() {
    el.status.hidden = true;
    el.status.classList.remove('is-error');
  }
  function setConnection(kind, text) {
    el.connection.className = `bt-live-indicator is-${kind}`;
    el.connection.querySelector('span').textContent = text;
  }
  function getColorPreference() {
    const saved = safeRead(COLORS_KEY, {});
    const valid = (value) => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
    return { up: valid(saved.up) ? saved.up : DEFAULT_COLORS.up, down: valid(saved.down) ? saved.down : DEFAULT_COLORS.down };
  }
  function loadFavoritePreference() {
    const saved = safeRead(FAVORITES_KEY, null);
    return Array.isArray(saved) ? saved.filter((tool, index, list) => TOOL_LABELS[tool] && list.indexOf(tool) === index) : ['trendline', 'horizontal', 'rectangle'];
  }
  function loadStudyPreference() {
    const saved = safeRead(STUDIES_KEY, {});
    return { sma20: saved.sma20 === true, sma50: saved.sma50 === true, volume: saved.volume !== false };
  }

  function setupChart() {
    if (state.chart) return true;
    const api = window.LightweightCharts;
    if (!api?.createChart || !api?.CandlestickSeries || !api?.LineSeries || !api?.AreaSeries || !api?.HistogramSeries) {
      setStatus('The chart library could not load. Refresh the page to try again.', true);
      return false;
    }
    const rect = el.host.getBoundingClientRect();
    state.chart = api.createChart(el.host, {
      width: Math.max(320, Math.round(rect.width || el.host.clientWidth || 900)),
      height: Math.max(380, Math.round(rect.height || el.host.clientHeight || 620)),
      layout: { background: { type: 'solid', color: '#ffffff' }, textColor: '#6d7580', fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', attributionLogo: true },
      grid: { vertLines: { color: '#f0f2f4' }, horzLines: { color: '#f0f2f4' } },
      rightPriceScale: { borderColor: '#e6e8eb', scaleMargins: { top: 0.1, bottom: 0.2 } },
      timeScale: { borderColor: '#e6e8eb', timeVisible: true, secondsVisible: false, rightOffset: 9, fixRightEdge: false, lockVisibleTimeRangeOnResize: true },
      crosshair: { mode: api.CrosshairMode?.Normal ?? 0, vertLine: { color: '#a1a7af', width: 1, style: 2, labelBackgroundColor: '#343a40' }, horzLine: { color: '#a1a7af', width: 1, style: 2, labelBackgroundColor: '#343a40' } },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
      localization: { locale: 'en-US', dateFormat: 'yyyy-MM-dd' },
    });
    state.volume = state.chart.addSeries(api.HistogramSeries, { priceScaleId: 'volume', priceFormat: { type: 'volume' }, lastValueVisible: false, priceLineVisible: false, base: 0 });
    state.chart.priceScale('volume').applyOptions({ visible: false, scaleMargins: { top: 0.86, bottom: 0.01 }, borderVisible: false });
    state.sma20 = state.chart.addSeries(api.LineSeries, { color: '#477be8', lineWidth: 2, lastValueVisible: false, priceLineVisible: false, crosshairMarkerVisible: false });
    state.sma50 = state.chart.addSeries(api.LineSeries, { color: '#c49a1a', lineWidth: 2, lastValueVisible: false, priceLineVisible: false, crosshairMarkerVisible: false });
    setChartType(el.chartType.value || 'candles');
    state.chart.subscribeClick(onChartClick);
    state.chart.subscribeCrosshairMove((param) => {
      if (state.mode === 'replay' || !param?.time) return;
      const bar = state.priceSeries && param.seriesData?.get(state.priceSeries);
      if (bar) renderQuote(findBar(Number(param.time)) || bar, param.time);
    });
    if ('ResizeObserver' in window) {
      const observer = new ResizeObserver(() => resizeChart());
      observer.observe(el.host);
    } else window.addEventListener('resize', resizeChart);
    return true;
  }

  function setChartType(type) {
    if (!state.chart) { state.chartType = type; return; }
    const api = window.LightweightCharts;
    if (!['candles', 'line', 'area'].includes(type)) type = 'candles';
    if (state.priceSeries) state.chart.removeSeries(state.priceSeries);
    state.chartType = type;
    if (type === 'candles') {
      state.priceSeries = state.chart.addSeries(api.CandlestickSeries, { upColor: state.colors.up, downColor: state.colors.down, borderUpColor: state.colors.up, borderDownColor: state.colors.down, wickUpColor: state.colors.up, wickDownColor: state.colors.down, borderVisible: false, priceLineVisible: true });
      state.candles = state.priceSeries;
    } else if (type === 'line') {
      state.priceSeries = state.chart.addSeries(api.LineSeries, { color: '#20262e', lineWidth: 2, priceLineVisible: true, crosshairMarkerVisible: true });
      state.candles = state.priceSeries;
    } else {
      state.priceSeries = state.chart.addSeries(api.AreaSeries, { lineColor: '#20262e', topColor: 'rgba(196,154,26,0.20)', bottomColor: 'rgba(196,154,26,0.01)', lineWidth: 2, priceLineVisible: true, crosshairMarkerVisible: true });
      state.candles = state.priceSeries;
    }
    if (state.bars.length) renderData(false);
    renderDrawings();
  }
  function resizeChart() {
    if (!state.chart || !el.host) return;
    const rect = el.host.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) state.chart.applyOptions({ width: Math.round(rect.width), height: Math.round(rect.height) });
    renderDrawings();
  }
  function currentDrawingKey() { return `${state.symbol}:${state.interval}`; }
  function loadDrawings() {
    const all = safeRead(DRAWINGS_KEY, {});
    return Array.isArray(all?.[currentDrawingKey()]) ? all[currentDrawingKey()].slice(-200) : [];
  }
  function saveDrawings() {
    const all = safeRead(DRAWINGS_KEY, {});
    all[currentDrawingKey()] = state.drawings.slice(-200);
    safeWrite(DRAWINGS_KEY, all);
  }
  function viewBars() {
    if (state.mode === 'replay') return state.bars.slice(0, state.cursor + 1);
    const result = state.bars.slice();
    if (state.liveBar && (!result.length || state.liveBar.time > result[result.length - 1].time)) result.push(state.liveBar);
    return result;
  }
  function toPriceData(bars) {
    if (state.chartType === 'candles') return bars.map(({ time, open, high, low, close }) => ({ time, open, high, low, close }));
    return bars.map(({ time, close }) => ({ time, value: close }));
  }
  function movingAverage(bars, period) {
    const data = [];
    let sum = 0;
    bars.forEach((bar, index) => {
      sum += bar.close;
      if (index >= period) sum -= bars[index - period].close;
      if (index >= period - 1) data.push({ time: bar.time, value: sum / period });
    });
    return data;
  }
  function renderIndicators(bars) {
    state.sma20.setData(state.studies.sma20 ? movingAverage(bars, 20) : []);
    state.sma50.setData(state.studies.sma50 ? movingAverage(bars, 50) : []);
    state.studyCount.textContent = String(Number(state.studies.sma20) + Number(state.studies.sma50));
    state.studyLegend.replaceChildren();
    if (state.studies.sma20) state.studyLegend.append(makeLegend('#477be8', 'SMA 20'));
    if (state.studies.sma50) state.studyLegend.append(makeLegend('#c49a1a', 'SMA 50'));
  }
  function makeLegend(color, text) {
    const item = document.createElement('span'); item.className = 'bt-study-legend-item';
    const dot = document.createElement('i'); dot.style.background = color;
    item.append(dot, document.createTextNode(text)); return item;
  }
  function renderVolume(bars) {
    state.volume.applyOptions({ visible: state.studies.volume });
    state.volume.setData(state.studies.volume ? bars.map((bar) => ({ time: bar.time, value: bar.volume, color: bar.close >= bar.open ? `${state.colors.up}35` : `${state.colors.down}35` })) : []);
  }
  function renderQuote(bar, time = bar?.time) {
    if (!bar) return;
    el.open.textContent = priceFormat(bar.open ?? bar.value);
    el.high.textContent = priceFormat(bar.high ?? bar.value);
    el.low.textContent = priceFormat(bar.low ?? bar.value);
    el.close.textContent = priceFormat(bar.close ?? bar.value);
    el.candleTime.textContent = utcTime(time);
    el.close.classList.toggle('is-up', (bar.close ?? bar.value) >= (bar.open ?? bar.value));
    el.close.classList.toggle('is-down', (bar.close ?? bar.value) < (bar.open ?? bar.value));
  }
  function renderData(fitContent = false) {
    if (!state.priceSeries || !state.bars.length) return;
    const before = state.chart.timeScale().getVisibleLogicalRange();
    const view = viewBars();
    state.priceSeries.setData(toPriceData(view));
    renderIndicators(view);
    renderVolume(view);
    if (fitContent || !before) state.chart.timeScale().fitContent();
    else if (state.mode === 'replay') applyReplayRange();
    else {
      const count = view.length;
      const nearEdge = count - before.to <= 14;
      if (nearEdge && state.followingLive) {
        const width = Math.max(35, before.to - before.from);
        state.chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, count - width + 1), to: count + 8 });
      } else state.chart.timeScale().setVisibleLogicalRange(before);
    }
    const last = view[view.length - 1];
    renderQuote(last, last.time);
    updateSourceLine();
    updateProgress();
    renderDrawings();
  }
  function updateSourceLine() {
    if (!state.bars.length) return;
    const mode = state.mode === 'replay' ? `Replay at ${utcTime(state.bars[state.cursor]?.time)}` : `Live market · updated ${retrievalTime()}`;
    el.sourceLine.textContent = `${state.symbol} · Binance Spot · ${state.interval} · ${mode}`;
  }
  function applyReplayRange() {
    if (!state.bars.length) return;
    const width = 112;
    const left = Math.max(0, state.cursor - width + 1);
    state.chart.timeScale().setVisibleLogicalRange({ from: left, to: state.cursor + 10 });
  }
  function updateProgress() {
    const bars = state.bars;
    if (!bars.length) return;
    const lastIndex = bars.length - 1;
    const activeIndex = state.mode === 'replay' ? state.cursor : lastIndex;
    el.scrubber.max = String(lastIndex);
    el.scrubber.value = String(activeIndex);
    el.scrubber.disabled = state.mode !== 'replay';
    el.startTime.textContent = utcTime(bars[0].time);
    el.endTime.textContent = utcTime(bars[lastIndex].time);
    const percent = lastIndex ? activeIndex / lastIndex * 100 : 100;
    el.progressFill.style.width = `${percent}%`;
    el.progressLabel.textContent = state.mode === 'replay' ? `${activeIndex + 1} / ${bars.length} candles · ${Math.round(percent)}%` : `${bars.length.toLocaleString()} bars loaded`;
    el.selectedLabel.textContent = state.mode === 'replay' ? `${symbolLabel()} · ${state.interval} · ${utcTime(bars[activeIndex]?.time)}` : 'Select a candle to start';
  }

  async function loadBars(forSelection = false) {
    pause();
    if (!setupChart()) return;
    state.request?.abort();
    closeStream();
    const controller = new AbortController(); state.request = controller;
    state.symbol = el.symbol.value;
    state.interval = el.interval.value;
    state.mode = forSelection ? 'selecting' : 'live';
    state.bars = []; state.liveBar = null; state.cursor = 0; state.drawings = [];
    el.marketLabel.textContent = symbolLabel();
    el.marketSource.textContent = `Binance Spot · ${state.mode === 'live' ? 'Live' : 'Select replay start'}`;
    state.priceSeries.setData([]); state.volume.setData([]); state.sma20.setData([]); state.sma50.setData([]);
    el.open.textContent = el.high.textContent = el.low.textContent = el.close.textContent = '—';
    el.candleTime.textContent = 'Waiting for candle data…';
    renderMode();
    setConnection('connecting', 'Loading');
    setStatus(`Loading up to ${CANDLE_LIMIT.toLocaleString()} completed ${state.interval} candles for ${symbolLabel()} from Binance Spot…`);
    try {
      const url = new URL(API_BASE);
      url.searchParams.set('symbol', state.symbol); url.searchParams.set('interval', state.interval); url.searchParams.set('limit', String(CANDLE_LIMIT));
      const response = await fetch(url, { method: 'GET', mode: 'cors', cache: 'no-store', signal: controller.signal, headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(response.status === 429 ? 'Binance rate-limited this request. Wait a moment, then try again.' : `Binance returned HTTP ${response.status}. Try again in a moment.`);
      const rows = await response.json();
      if (!Array.isArray(rows)) throw new Error('Binance returned an unexpected candle-data response.');
      const now = Date.now();
      const bars = rows.map((row) => ({ time: Math.floor(Number(row[0]) / 1000), open: Number(row[1]), high: Number(row[2]), low: Number(row[3]), close: Number(row[4]), volume: Number(row[5]), closeTime: Number(row[6]) }))
        .filter((bar) => Number.isFinite(bar.time) && bar.closeTime < now && [bar.open, bar.high, bar.low, bar.close, bar.volume].every(Number.isFinite) && bar.volume >= 0 && bar.high >= Math.max(bar.open, bar.close) && bar.low <= Math.min(bar.open, bar.close));
      if (!bars.length) throw new Error('No completed candles were returned for this market and interval.');
      if (bars.some((bar, index) => index > 0 && bar.time <= bars[index - 1].time)) throw new Error('Binance returned candles in an unexpected time order.');
      if (state.request !== controller) return;
      state.bars = bars; state.retrievedAt = new Date(); state.drawings = loadDrawings();
      syncQuickIntervals(); clearStatus(); renderData(true); renderMode();
      setConnection('connecting', 'Connecting live');
      connectStream();
      window.requestAnimationFrame(resizeChart);
    } catch (error) {
      if (error?.name === 'AbortError') return;
      state.bars = []; state.liveBar = null;
      state.priceSeries.setData([]); state.volume.setData([]); state.sma20.setData([]); state.sma50.setData([]);
      el.scrubber.disabled = true; el.progressLabel.textContent = 'Data unavailable';
      el.sourceLine.textContent = 'Binance Spot market data unavailable · no sample candles shown';
      setConnection('error', 'Feed unavailable');
      setStatus(error?.message || 'Could not load Binance market candles. Check your connection and try again.', true);
      renderMode();
    } finally {
      if (state.request === controller) state.request = null;
    }
  }

  function closeStream() {
    if (state.reconnectTimer) window.clearTimeout(state.reconnectTimer);
    state.reconnectTimer = 0;
    const old = state.socket; state.socket = null;
    if (old) { old.onclose = null; try { old.close(); } catch { /* ignore a closing socket */ } }
  }
  function connectStream() {
    closeStream();
    if (!state.bars.length) return;
    const symbol = state.symbol;
    const interval = state.interval;
    const socket = new WebSocket(`${STREAM_BASE}/${symbol.toLowerCase()}@kline_${interval}`);
    state.socket = socket;
    socket.onopen = () => { if (state.socket !== socket) return; setConnection(state.mode === 'replay' ? 'replay' : 'live', state.mode === 'replay' ? 'Live feed ready' : 'Live'); };
    socket.onmessage = (message) => {
      if (state.socket !== socket) return;
      try { const payload = JSON.parse(message.data); if (payload?.k) acceptKline(payload.k); } catch (error) { console.warn('Could not parse Binance kline update', error); }
    };
    socket.onerror = () => { if (state.socket === socket) setConnection('error', 'Feed reconnecting'); };
    socket.onclose = () => {
      if (state.socket !== socket) return;
      state.socket = null; setConnection('connecting', 'Reconnecting');
      state.reconnectTimer = window.setTimeout(() => { if (state.symbol === symbol && state.interval === interval) connectStream(); }, 4000);
    };
  }
  function acceptKline(kline) {
    const bar = { time: Math.floor(Number(kline.t) / 1000), open: Number(kline.o), high: Number(kline.h), low: Number(kline.l), close: Number(kline.c), volume: Number(kline.v), closeTime: Number(kline.T) };
    if (!Number.isFinite(bar.time) || ![bar.open, bar.high, bar.low, bar.close, bar.volume].every(Number.isFinite)) return;
    const last = state.bars[state.bars.length - 1];
    if (kline.x) {
      if (last?.time === bar.time) state.bars[state.bars.length - 1] = bar;
      else if (!last || bar.time > last.time) state.bars.push(bar);
      if (state.bars.length > CANDLE_LIMIT) {
        state.bars.shift();
        if (state.mode === 'replay') state.cursor = Math.max(0, state.cursor - 1);
      }
      state.liveBar = null;
    } else state.liveBar = bar;
    if (state.mode !== 'replay') renderData(false);
    else updateProgress();
    if (state.mode === 'replay') setConnection('replay', 'Replay · feed ready');
    else setConnection('live', 'Live');
  }
  function findBar(time) { return state.bars.find((bar) => bar.time === Number(time)); }
  function onChartClick(param) {
    if (state.mode !== 'selecting' || !param?.time) return;
    const time = Number(param.time);
    let index = state.bars.findIndex((bar) => bar.time === time);
    if (index < 0) {
      index = state.bars.reduce((best, bar, i) => Math.abs(bar.time - time) < Math.abs(state.bars[best].time - time) ? i : best, 0);
    }
    if (index < 0 || !state.bars[index]) return;
    state.cursor = index;
    state.mode = 'replay';
    pause(); renderData(false); renderMode();
    setConnection(state.socket?.readyState === WebSocket.OPEN ? 'replay' : 'connecting', 'Replay · live feed ready');
  }
  function renderMode() {
    const selecting = state.mode === 'selecting';
    const replaying = state.mode === 'replay';
    el.replayToggle.setAttribute('aria-pressed', String(selecting || replaying));
    el.replayToggle.classList.toggle('is-active', selecting || replaying);
    el.replayLabel.textContent = replaying ? 'Exit replay' : selecting ? 'Cancel replay' : 'Bar Replay';
    el.selectionBanner.hidden = !selecting;
    el.player.hidden = !replaying;
    el.marketSource.textContent = `Binance Spot · ${replaying ? 'Bar replay' : selecting ? 'Choose start bar' : 'Live'}`;
    el.wrap.classList.toggle('is-replay-selecting', selecting);
    el.wrap.classList.toggle('is-replaying', replaying);
    el.wrap.classList.toggle('is-drawing', state.activeTool !== 'cursor');
    if (replaying) setConnection('replay', state.socket?.readyState === WebSocket.OPEN ? 'Replay · live feed ready' : 'Replay');
    updateProgress();
  }
  function toggleReplay() {
    if (state.mode === 'live') {
      pause();
      if (!state.bars.length) { loadBars(true); return; }
      state.mode = 'selecting'; renderMode();
      setConnection('selecting', 'Select start bar');
    } else {
      pause(); state.mode = 'live';
      if (state.bars.length) { renderData(false); renderMode(); }
      else renderMode();
      if (state.socket?.readyState !== WebSocket.OPEN && state.bars.length) connectStream();
    }
  }
  function setReplayCursor(index) {
    if (!state.bars.length || state.mode !== 'replay') return;
    pause(); state.cursor = Math.max(0, Math.min(state.bars.length - 1, Math.round(index)));
    renderData(false); renderMode();
  }
  function play() {
    if (state.mode !== 'replay' || !state.bars.length) return;
    if (state.cursor >= state.bars.length - 1) { state.cursor = 0; renderData(false); }
    pause(); state.playing = true;
    el.play.innerHTML = 'Ⅱ <span>Pause</span>'; el.play.setAttribute('aria-label', 'Pause replay'); el.play.setAttribute('aria-pressed', 'true');
    const rate = Math.max(1, Number(el.speed.value) || 1);
    state.timer = window.setInterval(() => {
      if (state.cursor >= state.bars.length - 1) { pause(); return; }
      state.cursor += 1; renderData(false); renderMode();
    }, Math.max(100, 1000 / rate));
  }
  function pause() {
    state.playing = false;
    if (state.timer) window.clearInterval(state.timer);
    state.timer = 0;
    if (el.play) { el.play.innerHTML = '▶ <span>Play</span>'; el.play.setAttribute('aria-label', 'Play replay'); el.play.setAttribute('aria-pressed', 'false'); }
  }
  function updateCandleColors() {
    state.colors = { up: el.upColor.value, down: el.downColor.value };
    safeWrite(COLORS_KEY, state.colors);
    if (state.chartType === 'candles' && state.priceSeries) state.priceSeries.applyOptions({ upColor: state.colors.up, downColor: state.colors.down, wickUpColor: state.colors.up, wickDownColor: state.colors.down, borderUpColor: state.colors.up, borderDownColor: state.colors.down });
    if (state.bars.length) renderVolume(viewBars());
  }
  function applyStudies() {
    state.studies.sma20 = Boolean($('[data-replay-study="sma20"]')?.checked);
    state.studies.sma50 = Boolean($('[data-replay-study="sma50"]')?.checked);
    state.studies.volume = Boolean(el.volumeToggle.checked);
    safeWrite(STUDIES_KEY, state.studies);
    if (state.bars.length) renderData(false);
    else renderIndicators([]);
  }
  function syncQuickIntervals() {
    $$('[data-quick-interval]').forEach((button) => {
      const active = button.dataset.quickInterval === state.interval;
      button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active));
    });
    el.interval.value = state.interval;
  }
  function togglePopover(which) {
    const pairs = [
      [el.styleToggle, el.stylePopover, which === 'style'], [el.favoritesToggle, el.favoritesPopover, which === 'favorites'],
      [el.studiesToggle, el.studiesPopover, which === 'studies'], [el.settingsToggle, el.settingsPopover, which === 'settings'],
    ];
    pairs.forEach(([button, popover, open]) => {
      if (!button || !popover) return;
      const next = Boolean(open && popover.hidden); popover.hidden = !next; button.setAttribute('aria-expanded', String(next));
    });
  }
  function setActiveTool(tool) {
    state.activeTool = tool;
    const drawing = tool !== 'cursor';
    el.drawingLayer.classList.toggle('is-active', drawing);
    el.selectTool.classList.toggle('active', !drawing); el.selectTool.setAttribute('aria-pressed', String(!drawing));
    el.favorites.querySelectorAll('[data-replay-tool]').forEach((button) => {
      const active = button.dataset.replayTool === tool; button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active));
    });
    el.activeToolLabel.textContent = drawing ? `${TOOL_LABELS[tool]} · drag on chart` : 'Select / pan chart';
    el.wrap.classList.toggle('is-drawing', drawing);
  }
  function renderFavoriteTools() {
    el.favorites.replaceChildren();
    state.favoriteTools.forEach((tool) => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'bt-drawing-tool'; button.dataset.replayTool = tool;
      button.textContent = TOOL_LABELS[tool]; button.title = `Activate ${TOOL_LABELS[tool]}`;
      button.setAttribute('aria-pressed', String(state.activeTool === tool));
      button.addEventListener('click', () => setActiveTool(state.activeTool === tool ? 'cursor' : tool));
      el.favorites.append(button);
    });
    $$('[data-tool-favorite]').forEach((checkbox) => { checkbox.checked = state.favoriteTools.includes(checkbox.dataset.toolFavorite); });
    if (!state.favoriteTools.includes(state.activeTool)) setActiveTool('cursor');
  }
  function toChartPoint(event) {
    const rect = el.wrap.getBoundingClientRect();
    const x = event.clientX - rect.left, y = event.clientY - rect.top;
    const width = Math.max(0, rect.width - 70), height = Math.max(0, rect.height - 25);
    if (x < 0 || x > width || y < 0 || y > height) return null;
    const time = state.chart?.timeScale().coordinateToTime(x), price = state.priceSeries?.coordinateToPrice(y);
    return time == null || price == null ? null : { time, price };
  }
  function svgElement(type, attrs) {
    const node = document.createElementNS('http://www.w3.org/2000/svg', type);
    Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, String(value)));
    return node;
  }
  function drawingNode(drawing, draft = false) {
    const x1 = state.chart?.timeScale().timeToCoordinate(drawing.start.time), y1 = state.priceSeries?.priceToCoordinate(drawing.start.price);
    const x2 = state.chart?.timeScale().timeToCoordinate(drawing.end.time), y2 = state.priceSeries?.priceToCoordinate(drawing.end.price);
    const width = el.wrap.clientWidth, height = el.wrap.clientHeight;
    const klass = `bt-drawing-line${draft ? ' draft' : ''}`;
    if (drawing.type === 'horizontal' && y1 != null) return svgElement('line', { x1: 0, y1, x2: width - 64, y2: y1, class: klass });
    if (drawing.type === 'vertical' && x1 != null) return svgElement('line', { x1, y1: 0, x2: x1, y2: height - 25, class: klass });
    if (x1 == null || y1 == null || x2 == null || y2 == null) return null;
    if (drawing.type === 'trendline') return svgElement('line', { x1, y1, x2, y2, class: klass });
    if (drawing.type === 'rectangle') return svgElement('rect', { x: Math.min(x1, x2), y: Math.min(y1, y2), width: Math.max(1, Math.abs(x2 - x1)), height: Math.max(1, Math.abs(y2 - y1)), class: `bt-drawing-rect${draft ? ' draft' : ''}` });
    return null;
  }
  function renderDrawings() {
    if (!el.drawingLayer || !el.wrap) return;
    el.drawingLayer.setAttribute('viewBox', `0 0 ${Math.max(1, el.wrap.clientWidth)} ${Math.max(1, el.wrap.clientHeight)}`);
    el.drawingLayer.replaceChildren();
    state.drawings.forEach((drawing) => { const node = drawingNode(drawing); if (node) el.drawingLayer.append(node); });
    if (state.draft) { const node = drawingNode(state.draft, true); if (node) el.drawingLayer.append(node); }
  }
  function finishDrawing(point) {
    if (!state.draft) return;
    if (state.draft.type !== 'horizontal' && state.draft.type !== 'vertical') {
      state.draft.end = { time: point.time, price: point.price };
      if (state.draft.start.time === point.time && state.draft.start.price === point.price) { state.draft = null; renderDrawings(); return; }
    }
    state.drawings.push(state.draft); state.drawings = state.drawings.slice(-200); state.draft = null; saveDrawings(); renderDrawings();
  }
  function bindDrawingEvents() {
    el.drawingLayer.addEventListener('pointerdown', (event) => {
      if (state.activeTool === 'cursor' || event.button !== 0) return;
      const point = toChartPoint(event); if (!point) return;
      event.preventDefault();
      if (event.isTrusted && Number.isInteger(event.pointerId)) el.drawingLayer.setPointerCapture(event.pointerId);
      state.draft = { type: state.activeTool, start: { time: point.time, price: point.price }, end: { time: point.time, price: point.price } };
      if (state.activeTool === 'horizontal' || state.activeTool === 'vertical') finishDrawing(point); else renderDrawings();
    });
    el.drawingLayer.addEventListener('pointermove', (event) => {
      if (!state.draft || ['horizontal', 'vertical'].includes(state.draft.type)) return;
      const point = toChartPoint(event); if (!point) return;
      state.draft.end = { time: point.time, price: point.price }; renderDrawings();
    });
    el.drawingLayer.addEventListener('pointerup', (event) => {
      if (!state.draft || ['horizontal', 'vertical'].includes(state.draft.type)) return;
      const point = toChartPoint(event); if (point) finishDrawing(point);
    });
    el.drawingLayer.addEventListener('pointercancel', () => { state.draft = null; renderDrawings(); });
  }
  function bindEvents() {
    el.symbol.addEventListener('change', () => loadBars());
    el.interval.addEventListener('change', () => { syncQuickIntervals(); loadBars(); });
    $$('[data-quick-interval]').forEach((button) => button.addEventListener('click', () => { el.interval.value = button.dataset.quickInterval; syncQuickIntervals(); loadBars(); }));
    el.chartType.addEventListener('change', () => setChartType(el.chartType.value));
    el.replayToggle.addEventListener('click', toggleReplay);
    $('#replay-cancel-selection').addEventListener('click', toggleReplay);
    $('#replay-exit').addEventListener('click', toggleReplay);
    $('#replay-refresh').addEventListener('click', () => loadBars(state.mode === 'selecting'));
    $('#replay-start').addEventListener('click', () => setReplayCursor(0));
    $('#replay-previous').addEventListener('click', () => setReplayCursor(state.cursor - 1));
    $('#replay-next').addEventListener('click', () => setReplayCursor(state.cursor + 1));
    el.play.addEventListener('click', () => state.playing ? pause() : play());
    el.speed.addEventListener('change', () => { if (state.playing) play(); });
    el.scrubber.addEventListener('input', () => setReplayCursor(Number(el.scrubber.value)));
    el.upColor.value = state.colors.up; el.downColor.value = state.colors.down;
    el.upColor.addEventListener('input', updateCandleColors); el.downColor.addEventListener('input', updateCandleColors);
    $('#replay-color-reset').addEventListener('click', () => { el.upColor.value = DEFAULT_COLORS.up; el.downColor.value = DEFAULT_COLORS.down; updateCandleColors(); });
    el.styleToggle.addEventListener('click', (event) => { event.stopPropagation(); togglePopover('style'); });
    el.favoritesToggle.addEventListener('click', (event) => { event.stopPropagation(); togglePopover('favorites'); });
    el.studiesToggle.addEventListener('click', (event) => { event.stopPropagation(); togglePopover('studies'); });
    el.settingsToggle.addEventListener('click', (event) => { event.stopPropagation(); togglePopover('settings'); });
    $$('[data-tool-favorite]').forEach((checkbox) => checkbox.addEventListener('change', () => {
      state.favoriteTools = $$('[data-tool-favorite]:checked').map((input) => input.dataset.toolFavorite); safeWrite(FAVORITES_KEY, state.favoriteTools); renderFavoriteTools();
    }));
    $$('[data-replay-study]').forEach((checkbox) => { checkbox.checked = state.studies[checkbox.dataset.replayStudy]; checkbox.addEventListener('change', applyStudies); });
    el.volumeToggle.checked = state.studies.volume; el.volumeToggle.addEventListener('change', applyStudies);
    $('#chart-reset-view').addEventListener('click', () => { togglePopover(null); state.followingLive = true; if (state.mode === 'replay') applyReplayRange(); else state.chart.timeScale().fitContent(); });
    $('#replay-clear-drawings').addEventListener('click', () => { state.drawings = []; state.draft = null; saveDrawings(); renderDrawings(); togglePopover(null); });
    $('#replay-undo-drawing').addEventListener('click', () => { state.drawings.pop(); saveDrawings(); renderDrawings(); });
    $('#chart-fullscreen').addEventListener('click', async () => {
      try { if (!document.fullscreenElement) await $('#chart-workspace').requestFullscreen(); else await document.exitFullscreen(); }
      catch { setStatus('Fullscreen is not available in this browser.', true); }
    });
    el.chart?.addEventListener?.('scroll', () => {});
    document.addEventListener('click', (event) => {
      if (!event.target.closest('.bt-terminal-popover-anchor') && !event.target.closest('.bt-terminal-toolbar-main') && !event.target.closest('.bt-terminal-popover')) togglePopover(null);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        togglePopover(null);
        if (state.mode === 'selecting') toggleReplay();
        else if (state.activeTool !== 'cursor') setActiveTool('cursor');
      }
      if (event.code === 'Space' && state.mode === 'replay' && !['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON'].includes(document.activeElement?.tagName)) { event.preventDefault(); state.playing ? pause() : play(); }
    });
    bindDrawingEvents();
    window.addEventListener('beforeunload', closeStream);
  }

  function setMarket(symbol, interval) {
    const cleanSymbol = String(symbol || '').split(':').pop().toUpperCase();
    const validSymbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT'];
    const nextSymbol = validSymbols.includes(cleanSymbol) ? cleanSymbol : 'BTCUSDT';
    const nextInterval = intervalFromTv(interval);
    const changed = el.symbol.value !== nextSymbol || el.interval.value !== nextInterval;
    el.symbol.value = nextSymbol; el.interval.value = nextInterval; syncQuickIntervals();
    if (changed) loadBars();
  }
  function boot() {
    state.colors = getColorPreference(); state.favoriteTools = loadFavoritePreference(); state.studies = loadStudyPreference();
    bindEvents(); renderFavoriteTools(); setupChart(); loadBars();
  }

  boot();
  window.TradeVeraReplay = { load: loadBars, setMarket, getMarket: () => ({ symbol: state.symbol, interval: state.interval, mode: state.mode }) };
})();
