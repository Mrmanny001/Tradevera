(() => {
  const tabs = [...document.querySelectorAll('[data-settings-tab]')];
  const panels = [...document.querySelectorAll('[data-settings-panel]')];
  const status = document.querySelector('[data-settings-status]');
  const personalForm = document.querySelector('[data-settings-personal]');
  const preferencesForm = document.querySelector('[data-settings-preferences]');
  const securityForm = document.querySelector('[data-settings-security]');
  const nameInput = document.querySelector('#settings-name');
  const emailInput = document.querySelector('#settings-email');
  const joined = document.querySelector('[data-settings-joined]');
  const enabledInput = document.querySelector('#settings-reminders-enabled');
  const hourInput = document.querySelector('#settings-reminder-hour');
  const weeklyInput = document.querySelector('#settings-weekly-day');
  if (!tabs.length || !window.TJ) return;
  const showStatus = (message, isError = false) => { status.textContent = message; status.className = `settings-status${isError ? ' is-error' : ' is-success'}`; window.clearTimeout(showStatus.timer); showStatus.timer = window.setTimeout(() => { status.textContent = ''; status.className = 'settings-status'; }, 4200); };
  const setTab = (id) => { tabs.forEach((tab) => { const active = tab.dataset.settingsTab === id; tab.classList.toggle('active', active); tab.setAttribute('aria-selected', String(active)); }); panels.forEach((panel) => { panel.hidden = panel.dataset.settingsPanel !== id; }); history.replaceState(null, '', `#${id}`); };
  tabs.forEach((tab) => tab.addEventListener('click', () => setTab(tab.dataset.settingsTab)));
  for (let hour = 0; hour < 24; hour += 1) { const option = document.createElement('option'); option.value = String(hour); option.textContent = `${String(hour).padStart(2, '0')}:00`; hourInput.appendChild(option); }
  const formatDate = (value) => { const date = new Date(value); return Number.isNaN(date.getTime()) ? '' : `Joined ${date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}`; };
  const load = async () => {
    try {
      const data = await TJ.api('/api/settings');
      nameInput.value = data.user.name || '';
      emailInput.value = data.user.email || '';
      joined.textContent = formatDate(data.user.createdAt);
      enabledInput.checked = data.preferences.remindersEnabled;
      hourInput.value = String(data.preferences.reminderHour ?? 18);
      weeklyInput.value = String(data.preferences.weeklyDay ?? 0);
      localStorage.setItem('trade-vera-reminder-hour', String(data.preferences.reminderHour ?? 18));
      localStorage.setItem('trade-vera-reminders-enabled', String(Boolean(data.preferences.remindersEnabled)));
      localStorage.setItem('trade-vera-reminder-weekly-day', String(data.preferences.weeklyDay ?? 0));
    } catch (error) { showStatus(error.message, true); }
  };
  personalForm?.addEventListener('submit', async (event) => { event.preventDefault(); try { const data = await TJ.api('/api/settings', { method: 'PUT', body: JSON.stringify({ name: nameInput.value }) }); document.querySelectorAll('[data-user-name]').forEach((el) => { el.textContent = data.user.name; }); showStatus('Personal details saved.'); } catch (error) { showStatus(error.message, true); } });
  preferencesForm?.addEventListener('submit', async (event) => { event.preventDefault(); try { const data = await TJ.api('/api/settings', { method: 'PUT', body: JSON.stringify({ remindersEnabled: enabledInput.checked, reminderHour: Number(hourInput.value), weeklyDay: Number(weeklyInput.value) }) }); localStorage.setItem('trade-vera-reminder-hour', String(data.preferences.reminderHour)); localStorage.setItem('trade-vera-reminders-enabled', String(Boolean(data.preferences.remindersEnabled))); localStorage.setItem('trade-vera-reminder-weekly-day', String(data.preferences.weeklyDay ?? 0)); showStatus('Reminder preferences saved.'); } catch (error) { showStatus(error.message, true); } });
  securityForm?.addEventListener('submit', async (event) => { event.preventDefault(); const newPassword = securityForm.elements.newPassword.value; if (newPassword !== securityForm.elements.confirmPassword.value) { showStatus('New passwords do not match.', true); return; } try { await TJ.api('/api/settings/password', { method: 'POST', body: JSON.stringify({ currentPassword: securityForm.elements.currentPassword.value, newPassword }) }); securityForm.reset(); showStatus('Password updated.'); } catch (error) { showStatus(error.message, true); } });
  const hash = window.location.hash.slice(1); setTab(tabs.some((tab) => tab.dataset.settingsTab === hash) ? hash : 'personal');
  TJ.ready.then(load).catch(() => {});
})();
