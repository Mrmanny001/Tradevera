(() => {
  const page = document.querySelector('[data-auth-page]');
  const form = document.querySelector('[data-auth-form]');
  const errorBox = document.querySelector('.auth-error');
  if (!page || !form) return;

  const params = new URLSearchParams(window.location.search);
  const next = params.get('next') === '/dashboard.html' ? '/dashboard.html' : '/dashboard.html';
  const referralCode = (params.get('ref') || '').trim().toUpperCase();
  const messages = {
    google_state: 'That Google sign-in session expired. Please try again.',
    google_failed: 'Google sign-in could not be completed. Please try again or use email.',
    google_denied: 'Google sign-in was cancelled. You can try again or use email.',
    google_unavailable: 'Google sign-in is being configured. Please use email for now.',
    session_unavailable: 'Your session could not be checked. Please sign in again.',
  };

  function showError(message) {
    if (!errorBox) return;
    errorBox.textContent = message;
    errorBox.hidden = !message;
  }

  document.querySelectorAll('[data-password-toggle]').forEach((toggle) => {
    const input = document.getElementById(toggle.dataset.passwordToggle);
    if (!input) return;
    toggle.addEventListener('click', () => {
      const visible = input.type === 'text';
      input.type = visible ? 'password' : 'text';
      toggle.setAttribute('aria-label', visible ? 'Show password' : 'Hide password');
      toggle.setAttribute('aria-pressed', String(!visible));
      toggle.classList.toggle('is-visible', !visible);
    });
  });

  if (params.has('error')) showError(messages[params.get('error')] || 'Please try again.');
  document.querySelectorAll('[data-auth-link]').forEach((link) => {
    const target = link.getAttribute('href');
    const separator = target.includes('?') ? '&' : '?';
    const referralQuery = referralCode ? `&ref=${encodeURIComponent(referralCode)}` : '';
    link.setAttribute('href', `${target}${separator}next=${encodeURIComponent(next)}${referralQuery}`);
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    showError('');
    const submit = form.querySelector('button[type="submit"]');
    const original = submit.innerHTML;
    submit.disabled = true;
    submit.innerHTML = '<span>Saving your account…</span><span aria-hidden="true">·</span>';
    const data = Object.fromEntries(new FormData(form).entries());
    data.next = next;
    if (referralCode) data.referralCode = referralCode;
    try {
      const response = await fetch(`/api/auth/${page.dataset.authPage}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Please check your details and try again.');
      window.location.assign(result.redirect || next);
    } catch (error) {
      showError(error.message);
      submit.disabled = false;
      submit.innerHTML = original;
    }
  });
})();
