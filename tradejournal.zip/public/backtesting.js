(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const STORAGE_KEY = 'tradevera.backtesting.sessions.v1';
  const CHART_SYMBOL = 'BINANCE:BTCUSDT';
  const CHART_INTERVAL = '15';
  const INTERVAL_LABELS = { '1': '1m', '5': '5m', '15': '15m', '30': '30m', '60': '1h', '240': '4h', D: '1D' };
  const SYMBOL_LABELS = {
    'BINANCE:BTCUSDT': 'BTC / USDT · Binance',
    'BINANCE:ETHUSDT': 'ETH / USDT · Binance',
    'BINANCE:SOLUSDT': 'SOL / USDT · Binance',
    'OANDA:EURUSD': 'EUR / USD · OANDA',
    'OANDA:GBPUSD': 'GBP / USD · OANDA',
    'OANDA:USDJPY': 'USD / JPY · OANDA',
    'OANDA:XAUUSD': 'Gold · OANDA',
  };
  const state = { symbol: CHART_SYMBOL, interval: CHART_INTERVAL, side: 'long', currentSessionId: null, orders: [], activeTab: 'positions' };

  const samples = {
    positions: [
      { pair: 'GBPUSD', side: 'LONG', size: '0.50', entry: '1.26940', stop: '1.26690', pnl: '+$82.50', status: 'OPEN' },
      { pair: 'USDJPY', side: 'SHORT', size: '0.25', entry: '149.820', stop: '150.150', pnl: '−$18.75', status: 'OPEN' },
    ],
    orders: [
      { pair: 'EURUSD', side: 'BUY LIMIT', size: '0.25', price: '1.08120', created: '10:42 UTC', status: 'PENDING' },
      { pair: 'GBPJPY', side: 'SELL STOP', size: '0.10', price: '189.650', created: '09:18 UTC', status: 'PENDING' },
      { pair: 'USDCHF', side: 'BUY LIMIT', size: '0.20', price: '0.88410', created: 'Yesterday', status: 'PENDING' },
    ],
    history: [
      { pair: 'EURUSD', side: 'LONG', entry: '1.07820', exit: '1.08350', result: '+1.6R', pnl: '+$160.00', date: '2025-02-18', entryTime: '08:15', exitTime: '10:30', duration: '2h 15m' },
      { pair: 'GBPUSD', side: 'SHORT', entry: '1.27410', exit: '1.27640', result: '−0.8R', pnl: '−$80.00', date: '2025-02-17', entryTime: '10:05', exitTime: '11:00', duration: '55m' },
      { pair: 'USDJPY', side: 'LONG', entry: '148.920', exit: '149.380', result: '+1.2R', pnl: '+$120.00', date: '2025-02-14', entryTime: '13:20', exitTime: '15:00', duration: '1h 40m' },
    ],
    journal: [
      { date: '2025-02-18', pair: 'EURUSD', setup: 'London pullback', note: 'Waited for a candle close before entry.' },
      { date: '2025-02-17', pair: 'GBPUSD', setup: 'Range rejection', note: 'Moved stop too early — review the rule.' },
    ],
  };

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  }

  function showMessage(message, type = '') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    window.setTimeout(() => toast.remove(), 3200);
  }

  function formatTime(value) {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return 'Just now';
    return `${new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' }).format(date)} UTC`;
  }

  function displaySymbol(symbol) {
    return SYMBOL_LABELS[symbol] || symbol.replace(':', ' · ');
  }

  function normalizeSymbol(symbol) {
    if (SYMBOL_LABELS[symbol]) return symbol;
    if (String(symbol).includes(':')) return symbol;
    const upper = String(symbol || '').toUpperCase();
    if (upper.endsWith('USDT') || ['BTC', 'ETH', 'SOL'].includes(upper)) return `BINANCE:${upper === 'BTC' ? 'BTCUSDT' : upper === 'ETH' ? 'ETHUSDT' : upper === 'SOL' ? 'SOLUSDT' : upper}`;
    return `OANDA:${upper}`;
  }

  function normalizeInterval(value) {
    const legacy = { '1m': '1', '5m': '5', '15m': '15', '30m': '30', '1H': '60', '4H': '240', '1D': 'D' };
    const normalized = legacy[value] || String(value || CHART_INTERVAL);
    return INTERVAL_LABELS[normalized] ? normalized : CHART_INTERVAL;
  }

  function applyChartPreset(symbol, interval) {
    const chart = $('#live-market-chart');
    if (!chart) return;
    state.symbol = normalizeSymbol(symbol);
    state.interval = normalizeInterval(interval);
    chart.setAttribute('symbol', state.symbol);
    chart.setAttribute('interval', state.interval);
    const status = $('#live-chart-status');
    if (status?.classList.contains('is-error')) {
      status.classList.remove('is-error');
      status.textContent = 'Updating the TradingView chart…';
      status.hidden = false;
      window.setTimeout(() => { if (!status.classList.contains('is-error')) status.hidden = true; }, 2500);
    }
  }

  function setChartMode(mode) {
    const selectedMode = mode === 'replay' ? 'replay' : 'live';
    $$('[data-chart-mode]').forEach((button) => {
      const active = button.dataset.chartMode === selectedMode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
      button.setAttribute('tabindex', active ? '0' : '-1');
    });
    $('#live-chart-panel').hidden = selectedMode !== 'live';
    $('#replay-chart-panel').hidden = selectedMode !== 'replay';
    $('#chart-mode-scope').textContent = selectedMode === 'live'
      ? 'Live market · TradingView feed'
      : 'Historical replay · Binance Spot candles';
    if (selectedMode === 'replay') window.TradeVeraReplay?.activate();
    else window.TradeVeraReplay?.deactivate();
  }

  function initLiveWidget() {
    const status = $('#live-chart-status');
    if (!status) return;
    let poll = 0;
    let timeout = 0;
    let watchTimeout = 0;
    const clearWatchers = () => {
      if (poll) window.clearInterval(poll);
      if (timeout) window.clearTimeout(timeout);
      if (watchTimeout) window.clearTimeout(watchTimeout);
      poll = timeout = watchTimeout = 0;
    };
    const hasChartFrame = () => (window.performance?.getEntriesByType?.('resource') || []).some((entry) =>
      entry.initiatorType === 'iframe' && entry.responseEnd > 0 && entry.name.includes('tradingview-widget.com/embed-widget/advanced-chart')
    );
    const showFailure = () => {
      clearWatchers();
      status.classList.add('is-error');
      status.textContent = 'TradingView could not load the embedded chart. Refresh or open a chart provider in a separate tab.';
    };
    const markLoaded = () => {
      clearWatchers();
      status.classList.remove('is-error');
      status.textContent = 'TradingView chart frame loaded. Confirm the selected symbol and feed status in the chart.';
      window.setTimeout(() => { status.hidden = true; }, 1400);
    };
    if (hasChartFrame()) {
      markLoaded();
      return;
    }
    if (!customElements.get('tv-advanced-chart')) {
      const script = document.createElement('script');
      script.type = 'module';
      script.src = 'https://widgets.tradingview-widget.com/w/en/tv-advanced-chart.js';
      script.addEventListener('error', showFailure, { once: true });
      document.head.appendChild(script);
    }
    poll = window.setInterval(() => { if (hasChartFrame()) markLoaded(); }, 500);
    timeout = window.setTimeout(() => {
      if (hasChartFrame()) {
        markLoaded();
        return;
      }
      timeout = 0;
      status.classList.add('is-error');
      status.textContent = 'TradingView could not load the embedded chart. Refresh or open a chart provider in a separate tab.';
      watchTimeout = window.setTimeout(() => {
        if (poll) window.clearInterval(poll);
        poll = watchTimeout = 0;
      }, 120000);
    }, 45000);
  }

  function loadSessions() {
    const starter = [{ id: 'starter-btc-preset', name: 'BTC / USDT · 15m', symbol: CHART_SYMBOL, timeframe: CHART_INTERVAL, lastAccessed: '2025-02-18T09:30:00.000Z' }];
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (!Array.isArray(parsed)) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(starter));
        return starter;
      }
      return parsed.filter((item) => item && typeof item === 'object').map((item) => ({
        ...item,
        symbol: normalizeSymbol(item.symbol),
        timeframe: normalizeInterval(item.timeframe),
      }));
    } catch {
      return [];
    }
  }

  function storeSessions(sessions) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
      return true;
    } catch {
      showMessage('Browser storage is unavailable. This preset was not saved.', 'error');
      return false;
    }
  }

  function renderSessions() {
    const list = $('#session-list');
    const sessions = loadSessions().sort((first, second) => String(second.lastAccessed).localeCompare(String(first.lastAccessed)));
    if (!sessions.length) {
      list.innerHTML = '<div class="bt-session-empty">No chart presets yet. Create one to save a symbol and interval in this browser.</div>';
      return;
    }
    list.innerHTML = sessions.map((session) => {
      const last = session.demo ? 'Example preset' : `Saved in this browser`;
      return `<article class="bt-session-item"><div class="bt-session-main"><strong>${escapeHtml(session.name)}</strong><small>${escapeHtml(displaySymbol(session.symbol))} · ${escapeHtml(INTERVAL_LABELS[session.timeframe] || '15m')}</small><span class="bt-session-last">${last}</span></div><div class="bt-session-actions"><button type="button" data-resume-session="${escapeHtml(session.id)}">Apply</button><button class="delete" type="button" data-delete-session="${escapeHtml(session.id)}" aria-label="Delete ${escapeHtml(session.name)}">Delete</button></div></article>`;
    }).join('');
    list.querySelectorAll('[data-resume-session]').forEach((button) => button.addEventListener('click', () => resumeSession(button.dataset.resumeSession)));
    list.querySelectorAll('[data-delete-session]').forEach((button) => button.addEventListener('click', () => deleteSession(button.dataset.deleteSession)));
  }

  function createSession(event) {
    event.preventDefault();
    const name = $('#session-name').value.trim();
    const symbol = normalizeSymbol($('#session-symbol').value);
    const timeframe = normalizeInterval($('#session-timeframe').value);
    if (!name) return;
    const sessions = loadSessions();
    sessions.unshift({ id: `preset-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, symbol, timeframe, lastAccessed: new Date().toISOString() });
    if (!storeSessions(sessions)) return;
    $('#session-form').reset();
    $('#session-form').hidden = true;
    $('#new-session-toggle').setAttribute('aria-expanded', 'false');
    state.currentSessionId = sessions[0].id;
    applyChartPreset(symbol, timeframe);
    renderSessions();
    showMessage('Chart preset saved in this browser.');
  }

  function resumeSession(id) {
    const sessions = loadSessions();
    const session = sessions.find((item) => item.id === id);
    if (!session) return;
    state.currentSessionId = session.id;
    session.lastAccessed = new Date().toISOString();
    session.demo = false;
    storeSessions(sessions);
    applyChartPreset(session.symbol, session.timeframe);
    renderSessions();
    showMessage(`Applied ${session.name}.`);
  }

  function deleteSession(id) {
    const sessions = loadSessions().filter((item) => item.id !== id);
    storeSessions(sessions);
    if (state.currentSessionId === id) state.currentSessionId = null;
    renderSessions();
    showMessage('Chart preset removed from this browser.');
  }

  function updateRiskSummary() {
    const entry = Number($('#entry-price').value);
    const stop = Number($('#stop-price').value);
    const target = Number($('#target-price').value);
    const lots = Math.max(0, Number($('#position-size').value) || 0);
    const riskPercent = Math.max(0, Number($('#risk-percent').value) || 0);
    const account = Math.max(0, Number($('#account-balance').value) || 0);
    const directionValid = state.side === 'long' ? stop < entry && target > entry : stop > entry && target < entry;
    const distancePips = Math.abs(entry - stop) / 0.0001;
    const rewardPips = Math.abs(target - entry) / 0.0001;
    const estimatedRisk = distancePips * 10 * lots;
    const rr = distancePips > 0 ? rewardPips / distancePips : 0;
    $('#estimated-risk').textContent = directionValid ? `$${estimatedRisk.toFixed(2)} (${account ? (estimatedRisk / account * 100).toFixed(2) : '0.00'}%)` : 'Check levels';
    $('#estimated-risk').classList.toggle('risk-warning', !directionValid);
    $('#risk-reward').textContent = directionValid && Number.isFinite(rr) ? `${rr.toFixed(2)}R` : '—';
    $('#risk-target-amount').textContent = `$${(account * riskPercent / 100).toFixed(2)}`;
    return { valid: directionValid && entry > 0 && stop > 0 && target > 0 && lots > 0, entry, stop, target, lots, estimatedRisk, rr };
  }

  function tableMarkup(headers, rows, tableClass = '') {
    const className = tableClass ? ` ${escapeHtml(tableClass)}` : '';
    const label = tableClass === 'bt-history-table' ? ' aria-label="Closed trade history"' : '';
    return `<div class="bt-demo-table-wrap"><table class="bt-demo-table${className}"${label}><thead><tr>${headers.map((header) => `<th scope="col">${escapeHtml(header)}</th>`).join('')}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  }

  function pnlCell(value) {
    const escaped = escapeHtml(value);
    const tone = String(value).startsWith('+') ? 'bt-pnl-positive' : String(value).startsWith('−') || String(value).startsWith('-') ? 'bt-pnl-negative' : '';
    return `<span class="${tone}">${escaped}</span>`;
  }

  function renderBottomPanel() {
    const panel = $('#bottom-panel-content');
    if (state.activeTab === 'positions') {
      const rows = [...samples.positions, ...state.orders.filter((order) => order.kind === 'position').map((order) => ({ pair: order.pair, side: order.side, size: `${order.lots.toFixed(2)}`, entry: order.entry.toFixed(5), stop: order.stop.toFixed(5), pnl: '—', status: 'PAPER' }))]
        .map((item) => [escapeHtml(item.pair), `<span class="bt-direction ${item.side === 'SHORT' ? 'short' : ''}">${escapeHtml(item.side)}</span>`, escapeHtml(item.size), escapeHtml(item.entry), escapeHtml(item.stop), pnlCell(item.pnl), escapeHtml(item.status)]);
      panel.innerHTML = tableMarkup(['Symbol', 'Side', 'Size', 'Entry', 'Stop', 'Unrealized PnL', 'Status'], rows);
      return;
    }
    if (state.activeTab === 'orders') {
      const rows = state.orders.filter((order) => order.kind !== 'position')
        .map((item) => [escapeHtml(item.pair), escapeHtml(item.side), escapeHtml(item.size || `${item.lots?.toFixed(2)} lots`), escapeHtml(item.price || Number(item.entry).toFixed(5)), escapeHtml(item.created || 'Just now'), `<span class="bt-demo-tag">${escapeHtml(item.status || 'PAPER ONLY')}</span>`]);
      panel.innerHTML = rows.length ? tableMarkup(['Symbol', 'Order type', 'Size', 'Price', 'Created', 'Status'], rows) : '<div class="bt-empty-panel"><strong>No paper setups yet</strong><span>Use the example trade setup to add a local preview.</span></div>';
      return;
    }
    if (state.activeTab === 'history') {
      const rows = samples.history.map((item) => [
        `<span class="bt-history-date"><strong>${escapeHtml(item.date)}</strong><small>${escapeHtml(item.entryTime)}–${escapeHtml(item.exitTime)} UTC</small></span>`,
        `<strong class="bt-history-symbol">${escapeHtml(item.pair)}</strong>`,
        `<span class="bt-side-chip ${item.side === 'SHORT' ? 'short' : 'long'}">${escapeHtml(item.side)}</span>`,
        `<span class="bt-price-cell">${escapeHtml(item.entry)}</span>`,
        `<span class="bt-price-cell">${escapeHtml(item.exit)}</span>`,
        `<strong class="bt-history-pnl ${item.pnl.startsWith('+') ? 'positive' : 'negative'}">${escapeHtml(item.pnl)}</strong>`,
        `<span class="bt-r-multiple ${item.result.startsWith('+') ? 'positive' : 'negative'}">${escapeHtml(item.result)}</span>`,
        `<span class="bt-duration-cell">${escapeHtml(item.duration)}</span>`,
      ]);
      panel.innerHTML = `<div class="bt-history-panel"><div class="bt-history-toolbar"><div><strong>Closed trade log</strong><span>Sample trades · all values illustrative</span></div><span class="bt-history-count">${samples.history.length} trades <i>·</i> newest first</span></div>${tableMarkup(['Date / time', 'Symbol', 'Side', 'Entry', 'Exit', 'Net P&L', 'R-multiple', 'Duration'], rows, 'bt-history-table')}</div>`;
      return;
    }
    if (state.activeTab === 'journal') {
      const rows = samples.journal.map((item) => [escapeHtml(item.date), escapeHtml(item.pair), escapeHtml(item.setup), escapeHtml(item.note)]);
      panel.innerHTML = tableMarkup(['Date', 'Symbol', 'Setup', 'Journal note'], rows);
      return;
    }
    panel.innerHTML = renderPerformance();
  }

  function renderPerformance() {
    const values = [100, 102, 101, 105, 103, 107, 106, 111, 110, 114, 112, 118, 116, 121, 119, 125, 123, 129, 127, 134, 131, 138, 136, 142];
    const width = 720;
    const height = 120;
    const min = Math.min(...values) - 3;
    const max = Math.max(...values) + 3;
    const points = values.map((value, index) => `${(index / (values.length - 1) * width).toFixed(1)},${(height - (value - min) / (max - min) * height).toFixed(1)}`);
    const line = points.map((point, index) => `${index ? 'L' : 'M'}${point}`).join(' ');
    const area = `${line} L${width},${height} L0,${height} Z`;
    return `<div class="bt-performance-panel"><div class="bt-performance-copy"><small>Illustrative equity curve</small><strong>+$2,460</strong><span>Example values only · not verified or connected to live prices</span></div><svg class="bt-equity-chart" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="img" aria-label="Illustrative rising equity curve"><defs><linearGradient id="bt-equity-gradient" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#f2c230" stop-opacity=".2"/><stop offset="1" stop-color="#f2c230" stop-opacity="0"/></linearGradient></defs><path class="bt-equity-grid" d="M0 30H720M0 60H720M0 90H720"/><path class="bt-equity-area" d="${area}"/><path class="bt-equity-path" d="${line}"/></svg></div>`;
  }

  function setActiveTab(tab) {
    state.activeTab = tab;
    $$('[data-bottom-tab]').forEach((button) => {
      const active = button.dataset.bottomTab === tab;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
      button.setAttribute('tabindex', active ? '0' : '-1');
    });
    $('#bottom-panel-content').setAttribute('aria-labelledby', `bottom-tab-${tab}`);
    renderBottomPanel();
  }

  function setSide(side) {
    state.side = side;
    $$('[data-side]').forEach((button) => {
      const active = button.dataset.side === side;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    updateRiskSummary();
  }

  function addPaperSetup() {
    const summary = updateRiskSummary();
    if (!summary.valid) {
      showMessage('Check the example entry, stop, target, and position size before previewing.', 'error');
      return;
    }
    const order = {
      kind: 'order', pair: 'EURUSD', side: state.side === 'long' ? 'BUY PREVIEW' : 'SELL PREVIEW',
      size: `${summary.lots.toFixed(2)} lots`, price: summary.entry.toFixed(5), created: formatTime(new Date()), status: 'PAPER ONLY',
    };
    state.orders.unshift(order);
    $('#orders-count').textContent = String(state.orders.filter((item) => item.kind !== 'position').length);
    setActiveTab('orders');
    showMessage('Paper-trade preview added locally. No trade was executed.');
  }

  function bindEvents() {
    const menuToggle = $('[data-menu-toggle]');
    const sidebar = $('.sidebar');
    const scrim = $('.sidebar-scrim');
    const setMobileMenu = (open) => {
      sidebar?.classList.toggle('open', open);
      scrim?.classList.toggle('show', open);
      menuToggle?.setAttribute('aria-expanded', String(open));
      menuToggle?.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    };
    menuToggle?.addEventListener('click', () => setMobileMenu(!sidebar?.classList.contains('open')));
    scrim?.addEventListener('click', () => setMobileMenu(false));
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setMobileMenu(false); });

    $$('[data-side]').forEach((button) => button.addEventListener('click', () => setSide(button.dataset.side)));
    ['entry-price', 'stop-price', 'target-price', 'position-size', 'risk-percent', 'account-balance'].forEach((id) => $(`#${id}`).addEventListener('input', updateRiskSummary));
    $('#add-demo-order').addEventListener('click', addPaperSetup);

    const chartModes = $$('[data-chart-mode]');
    chartModes.forEach((button) => button.addEventListener('click', () => setChartMode(button.dataset.chartMode)));
    chartModes.forEach((button) => button.addEventListener('keydown', (event) => {
      const current = chartModes.indexOf(button);
      const next = event.key === 'ArrowRight' ? (current + 1) % chartModes.length
        : event.key === 'ArrowLeft' ? (current - 1 + chartModes.length) % chartModes.length
          : event.key === 'Home' ? 0 : event.key === 'End' ? chartModes.length - 1 : current;
      if (next === current) return;
      event.preventDefault();
      setChartMode(chartModes[next].dataset.chartMode);
      chartModes[next].focus();
    }));

    const tabs = $$('[data-bottom-tab]');
    tabs.forEach((button) => button.addEventListener('click', () => setActiveTab(button.dataset.bottomTab)));
    tabs.forEach((button) => button.addEventListener('keydown', (event) => {
      const current = tabs.indexOf(button);
      let next = current;
      if (event.key === 'ArrowRight') next = (current + 1) % tabs.length;
      else if (event.key === 'ArrowLeft') next = (current - 1 + tabs.length) % tabs.length;
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = tabs.length - 1;
      else return;
      event.preventDefault();
      setActiveTab(tabs[next].dataset.bottomTab);
      tabs[next].focus();
    }));

    $('#new-session-toggle').addEventListener('click', () => {
      const form = $('#session-form');
      form.hidden = !form.hidden;
      $('#new-session-toggle').setAttribute('aria-expanded', String(!form.hidden));
      if (!form.hidden) {
        $('#session-symbol').value = state.symbol;
        $('#session-timeframe').value = state.interval;
        $('#session-name').focus();
      }
    });
    $('#cancel-session').addEventListener('click', () => {
      $('#session-form').hidden = true;
      $('#new-session-toggle').setAttribute('aria-expanded', 'false');
    });
    $('#session-form').addEventListener('submit', createSession);
    $$('.bt-topnav a[href="#analytics"], .sidebar-nav a[href="#analytics"]').forEach((link) => link.addEventListener('click', () => setActiveTab('performance')));
  }

  function boot() {
    state.orders = samples.orders.map((order) => ({ ...order, kind: 'order' }));
    initLiveWidget();
    bindEvents();
    renderBottomPanel();
    renderSessions();
    updateRiskSummary();
  }

  try {
    boot();
  } catch (error) {
    console.error('Backtesting workspace could not initialize:', error);
    const status = $('#live-chart-status');
    if (status) {
      status.classList.add('is-error');
      status.hidden = false;
      status.textContent = 'The embedded chart or workspace failed to initialize. Refresh or open a provider in a separate tab.';
    }
    showMessage(error.message || 'Backtesting workspace could not initialize.', 'error');
  }
})();
