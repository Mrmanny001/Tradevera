(() => {
  const linkEl = document.querySelector('[data-referral-link]');
  const copyButton = document.querySelector('[data-copy-referral]');
  const shareButton = document.querySelector('[data-share-referral]');
  const signupsEl = document.querySelector('[data-referral-signups]');
  const tradersEl = document.querySelector('[data-referral-traders]');
  const emptyState = document.querySelector('[data-referrals-empty]');
  const table = document.querySelector('[data-referrals-table]');
  if (!linkEl || !window.TJ) return;
  let referralLink = '';
  const displayLink = (code) => `${window.location.origin}/signup.html?ref=${encodeURIComponent(code)}`;
  const setButtonText = (button, text) => { if (!button) return; const original = button.dataset.originalText || button.textContent; button.dataset.originalText = original; button.textContent = text; window.setTimeout(() => { button.textContent = original; }, 1800); };
  const renderReferrals = (referrals) => {
    if (!referrals.length) return;
    emptyState.hidden = true;
    table.hidden = false;
    table.innerHTML = `<div class="referrals-table-head"><span>Trader</span><span>Joined</span></div>${referrals.map((referral) => `<div class="referrals-table-row"><span><strong>${escapeHtml(referral.name || 'Trader')}</strong><small>${escapeHtml(referral.email || '')}</small></span><time>${formatDate(referral.joinedAt)}</time></div>`).join('')}`;
  };
  const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const formatDate = (value) => { const date = new Date(value); return Number.isNaN(date.getTime()) ? '—' : date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); };
  TJ.ready.then(async () => {
    const data = await TJ.api('/api/referrals/me');
    referralLink = displayLink(data.referralCode);
    linkEl.textContent = referralLink;
    if (signupsEl) signupsEl.textContent = String(data.signUps ?? 0);
    if (tradersEl) tradersEl.textContent = String(data.referredTraders ?? 0);
    renderReferrals(data.referrals || []);
  }).catch(() => { linkEl.textContent = 'Referral link unavailable'; });
  copyButton?.addEventListener('click', async () => { if (!referralLink) return; try { await navigator.clipboard.writeText(referralLink); setButtonText(copyButton, 'Copied'); } catch { setButtonText(copyButton, 'Copy failed'); } });
  shareButton?.addEventListener('click', async () => { if (!referralLink) return; if (navigator.share) { try { await navigator.share({ title: 'Join me on Trade Vera', text: 'Keep a clearer record of every trade with Trade Vera.', url: referralLink }); } catch {} } else { try { await navigator.clipboard.writeText(referralLink); setButtonText(shareButton, 'Link copied'); } catch {} } });
})();
