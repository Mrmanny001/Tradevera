# Trade Vera Landing Page Plan

## Scope

Build a responsive Trade Vera marketing site with a real account onboarding flow. The landing page preserves the confirmed Trade Vera identity and routes every primary CTA to the app-owned signup flow. Email/password accounts and Google OAuth are persisted through the managed server/database; no user metrics, testimonials, financial promises, or unsupported trading capabilities are invented.

## Design direction

- **Design movement:** editorial terminal minimalism — Swiss editorial structure and restrained fintech UI utility, expressed through the supplied graphite-and-gold Trade Vera reference.
- **Core principles:** clarity before spectacle; evidence over hype; calm hierarchy; product UI as the visual proof.
- **Color philosophy:** near-black graphite provides the terminal-level seriousness shown in the reference; warm gold acts as the single brand signal for actions, highlights, and chart emphasis; cream product surfaces preserve legibility; semantic green/red appear only inside the clearly labeled interface demonstration.
- **Layout paradigm:** a narrative scroll with indexed section rails, asymmetrical split layouts, full-bleed dark interludes, and connected progression lines instead of a repeated centered-card grid.
- **Signature elements:** indexed section labels (`01 / ...`), thin graph-paper rules, and a small gold "data pulse" motif that repeats in the TJ mark, CTA focus states, and chart emphasis.
- **Interaction philosophy:** interactions reveal structure rather than distract: mobile navigation opens cleanly, product showcase tabs change the demonstrated screen, FAQ items expand in place, and scroll reveals use short, low-distance transitions.
- **Animation:** hero UI rises once on load; chart lines draw when visible; section content uses opacity/translate reveal with reduced-motion fallback; hover states are crisp and brief.
- **Typography system:** Space Grotesk is the primary family with Inter and system fallbacks. Large display headings use tight tracking and short line lengths; body copy stays at readable measure; DM Mono is used only for metadata, section labels, and data values.
- **Brand essence:** Trade Vera is the calm, trader-specific record and review layer for turning executed trades into information you can learn from. Personality: measured, observant, precise.
- **Brand voice:** direct, specific, and non-promotional. Example lines: “Your trading history is more useful when it is structured.” and “See the decisions behind the outcome.”
- **Wordmark & logo:** a compact gold `bear logo artwork in a rounded graphite square, paired with a restrained Trade Vera wordmark. The small dot in the mark echoes a chart event without using a candle icon.
- **Signature brand color:** `#F2C230` warm signal gold — clear, ownable, and energetic enough to guide attention without implying profits.

## Implementation approach

Use a Node HTTP server with `mysql2` to serve `public/` on the configured port (default 3000) and handle account APIs. Use Node `scrypt` for password hashing, hashed random session tokens in the managed MySQL database, and a server-side Google authorization-code flow using only `openid email profile`. Use semantic HTML sections, CSS variables, responsive breakpoints, inline SVG for the product charts, and native browser APIs for scroll reveal, tabs, FAQ, mobile navigation, and auth forms.

## Project structure

- `server.js` — static serving, database initialization, email/password auth APIs, secure sessions, and Google OAuth.
- `Dockerfile` — production container entrypoint for the server-backed app.
- `public/index.html` — page structure, metadata, navigation, product demo UI, story sections, FAQ, CTA, and footer.
- `public/styles.css` — design tokens, responsive layout, component styling, motion, accessibility, and reduced-motion behavior.
- `public/app.js` — mobile nav, product showcase tabs, FAQ accordion, scroll reveal, and active chart draw state.
- `public/brand.svg` — durable project logo asset.
- `public/signup.html`, `public/login.html` — branded account creation and sign-in screens with Google buttons and accessible password show/hide controls.
- `public/auth.css`, `public/auth.js` — onboarding theme, password visibility behavior, and form behavior.
- `public/dashboard.html`, `public/dashboard.js` — protected post-auth trader workspace with date-window metrics, realized R/P&L/expectancy summaries, equity curve, most-traded pairs, user identity, logout behavior, and a responsive monthly realized-results calendar.
- `public/journal.html`, `public/journal.js` — authenticated trade journal with outcome/date filters, pair search, sortable date-ordered history, create/edit/delete actions, position size, P&L, strategy, time, emotion, discipline, live risk/planned-R:R/realized-R previews, and before/after trade-image upload controls.
- `public/risk-tools.html`, `public/risk.js` — authenticated FundedNext-inspired position-size flow with account balance, risk percentage, searchable instrument selection, entry/exit prices, reset/calculate actions, instrument-aware lot/units/risk outputs, and the preserved Quick R:R calculator below it.
- `public/workspace.css`, `public/workspace.js` — shared authenticated app shell, responsive sidebar/mobile navigation, consistent inline-SVG navigation icons and active states, accessible controls, session loading, and logout behavior.
- `public/manus-routes.json` — route manifest for landing, auth, dashboard, journal, and risk-tool pages.
- `app.config.ts` — project logo metadata pointing to the stable Preview asset URL.

## Product truth boundary

The landing-page product UI remains labeled “Interface demonstration” and uses illustrative values. The authenticated workspace starts empty for new accounts and computes metrics only from that user’s own persisted trades. Optional trade metadata (position size, P&L, strategy, trade time, emotion, and discipline) is stored with each user-owned trade; the database migration is additive and preserves existing records. Trade visuals are stored as user-owned, stage-specific database records with JPG/PNG/WebP/GIF validation and a 5 MB per-image limit. Copy describes journaling, review, and performance understanding without claiming integrations, outcomes, user counts, or finalized pricing. The browser-authenticated reference was used as a UI and behavior reference; its localStorage token approach was not copied because Trade Vera uses HttpOnly server sessions.
